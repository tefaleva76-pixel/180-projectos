-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, company_id, name, email, role, status)
  VALUES (
    NEW.id,
    (coalesce(NEW.raw_user_meta_data->>'company_id', '00000000-0000-0000-0000-000000000000'))::uuid,
    coalesce(NEW.raw_user_meta_data->>'name', 'مستخدم جديد'),
    NEW.email,
    'Site_Engineer',
    'Active'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Auto-update wallet on financial events
CREATE OR REPLACE FUNCTION process_wallet_update()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'Approved' AND NEW.payment_method = 'من العهدة النقدية' AND NEW.wallet_id IS NOT NULL THEN
    UPDATE wallets
    SET current_balance = current_balance - NEW.amount,
        total_spent = total_spent + NEW.amount,
        last_activity = CURRENT_TIMESTAMP
    WHERE wallet_id = NEW.wallet_id;
  END IF;

  IF NEW.event_type = 'شحن عهدة موقع' AND NEW.wallet_id IS NOT NULL THEN
    UPDATE wallets
    SET current_balance = current_balance + NEW.amount,
        total_received = total_received + NEW.amount,
        last_activity = CURRENT_TIMESTAMP
    WHERE wallet_id = NEW.wallet_id;
  END IF;

  IF NEW.status = 'Approved' THEN
    INSERT INTO budgets (project_id, phase_id, category_id, planned_amount, actual_amount)
    VALUES (NEW.project_id, NEW.phase_id, NEW.category_id, 0.00, NEW.amount)
    ON CONFLICT (project_id, phase_id, category_id)
    DO UPDATE SET actual_amount = budgets.actual_amount + NEW.amount;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_wallet_and_budget ON financial_events;
CREATE TRIGGER trigger_wallet_and_budget
AFTER INSERT OR UPDATE ON financial_events
FOR EACH ROW EXECUTE FUNCTION process_wallet_update();
