-- Projects: filtered by company_id
DROP POLICY IF EXISTS projects_access ON projects;
CREATE POLICY projects_access ON projects
  FOR ALL USING (
    company_id = get_my_company_id()
  );

-- Phases: via project ownership
DROP POLICY IF EXISTS phases_access ON phases;
CREATE POLICY phases_access ON phases
  FOR ALL USING (
    project_id IN (SELECT project_id FROM projects WHERE company_id = get_my_company_id())
  );

-- Categories: via project ownership
DROP POLICY IF EXISTS categories_access ON categories;
CREATE POLICY categories_access ON categories
  FOR ALL USING (
    project_id IN (SELECT project_id FROM projects WHERE company_id = get_my_company_id())
  );

-- Suppliers: by company
DROP POLICY IF EXISTS suppliers_access ON suppliers;
CREATE POLICY suppliers_access ON suppliers
  FOR ALL USING (
    company_id = get_my_company_id()
  );

-- Wallets: by company
DROP POLICY IF EXISTS wallets_access ON wallets;
CREATE POLICY wallets_access ON wallets
  FOR ALL USING (
    company_id = get_my_company_id()
  );

-- Budgets: via project ownership
DROP POLICY IF EXISTS budgets_access ON budgets;
CREATE POLICY budgets_access ON budgets
  FOR ALL USING (
    project_id IN (SELECT project_id FROM projects WHERE company_id = get_my_company_id())
  );

-- Documents: via project ownership
DROP POLICY IF EXISTS documents_access ON documents;
CREATE POLICY documents_access ON documents
  FOR ALL USING (
    project_id IN (SELECT project_id FROM projects WHERE company_id = get_my_company_id())
  );

-- Financial events: via project ownership
DROP POLICY IF EXISTS financial_events_access ON financial_events;
CREATE POLICY financial_events_access ON financial_events
  FOR ALL USING (
    project_id IN (SELECT project_id FROM projects WHERE company_id = get_my_company_id())
  );

-- Transaction meta: via event ownership
DROP POLICY IF EXISTS transaction_meta_access ON transaction_meta;
CREATE POLICY transaction_meta_access ON transaction_meta
  FOR ALL USING (
    event_id IN (SELECT event_id FROM financial_events WHERE project_id IN (SELECT project_id FROM projects WHERE company_id = get_my_company_id()))
  );

DROP POLICY IF EXISTS audit_logs_access ON audit_logs;
CREATE POLICY audit_logs_access ON audit_logs
  FOR ALL USING (
    user_id IN (SELECT user_id FROM profiles WHERE company_id = get_my_company_id())
  );
