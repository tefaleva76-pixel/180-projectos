CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enums
CREATE TYPE user_role_enum AS ENUM ('Owner', 'Accountant', 'Site_Engineer');
CREATE TYPE project_type_enum AS ENUM ('Residential', 'Industrial', 'Farm', 'Hotel', 'Mall', 'Custom');
CREATE TYPE phase_status_enum AS ENUM ('Not_Started', 'In_Progress', 'On_Hold', 'Completed');
CREATE TYPE event_type_enum AS ENUM (
  'مصروف', 'شراء أصل', 'إيراد', 'دفعة مورد', 'راتب / أجر',
  'إيجار', 'صيانة', 'مرتجع', 'سلفة', 'شحن عهدة موقع',
  'صرف من العهدة', 'مخصص'
);
CREATE TYPE payment_method_enum AS ENUM (
  'كاش / نقدي', 'تحويل بنكي', 'من العهدة النقدية', 'شيك', 'بطاقة ائتمان'
);
CREATE TYPE event_status_enum AS ENUM ('Pending', 'Approved', 'Rejected');
CREATE TYPE project_status_enum AS ENUM ('Planning', 'In_Progress', 'On_Hold', 'Completed');

-- 1. Companies (Multi-Tenant)
CREATE TABLE companies (
  company_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_name VARCHAR(255) NOT NULL,
  logo VARCHAR(512),
  address TEXT,
  phone VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Profiles (linked to Supabase auth.users)
CREATE TABLE profiles (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  company_id UUID NOT NULL REFERENCES companies(company_id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  role user_role_enum NOT NULL DEFAULT 'Site_Engineer',
  status VARCHAR(50) NOT NULL DEFAULT 'Active',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Projects
CREATE TABLE projects (
  project_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(company_id) ON DELETE CASCADE,
  project_name VARCHAR(255) NOT NULL,
  project_type project_type_enum NOT NULL DEFAULT 'Custom',
  location TEXT,
  budget DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  currency VARCHAR(10) NOT NULL DEFAULT 'EGP',
  status project_status_enum NOT NULL DEFAULT 'Planning',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Project Templates
CREATE TABLE project_templates (
  template_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_type project_type_enum NOT NULL UNIQUE,
  default_phases JSONB NOT NULL
);

-- 5. Phases (Cost Centers)
CREATE TABLE phases (
  phase_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  phase_name VARCHAR(255) NOT NULL,
  phase_order INT NOT NULL DEFAULT 1,
  status phase_status_enum NOT NULL DEFAULT 'Not_Started',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 6. Categories (Dynamic per project)
CREATE TABLE categories (
  category_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  category_name VARCHAR(255) NOT NULL,
  icon VARCHAR(100) NOT NULL DEFAULT 'box',
  color VARCHAR(20) NOT NULL DEFAULT '#1A1A1A',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 7. Suppliers
CREATE TABLE suppliers (
  supplier_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(company_id) ON DELETE CASCADE,
  supplier_name VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  email VARCHAR(255),
  tax_number VARCHAR(100),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 8. Wallets (Petty Cash / عهدة)
CREATE TABLE wallets (
  wallet_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE REFERENCES profiles(user_id) ON DELETE CASCADE,
  company_id UUID NOT NULL REFERENCES companies(company_id) ON DELETE CASCADE,
  current_balance DECIMAL(15,2) NOT NULL DEFAULT 0.00 CHECK (current_balance >= 0),
  total_received DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  total_spent DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  last_activity TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. Budgets
CREATE TABLE budgets (
  budget_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  phase_id UUID NOT NULL REFERENCES phases(phase_id) ON DELETE CASCADE,
  category_id UUID NOT NULL REFERENCES categories(category_id) ON DELETE CASCADE,
  planned_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  actual_amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  variance DECIMAL(15,2) GENERATED ALWAYS AS (planned_amount - actual_amount) STORED,
  CONSTRAINT unique_budget_node UNIQUE (project_id, phase_id, category_id)
);

-- 10. Documents Center
CREATE TABLE documents (
  document_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  document_type VARCHAR(100) NOT NULL,
  document_name VARCHAR(255) NOT NULL,
  expiry_date DATE,
  attachment_url VARCHAR(512) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 11. Financial Events (Core Ledger)
CREATE TABLE financial_events (
  event_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  phase_id UUID NOT NULL REFERENCES phases(phase_id) ON DELETE CASCADE,
  category_id UUID NOT NULL REFERENCES categories(category_id) ON DELETE CASCADE,
  supplier_id UUID REFERENCES suppliers(supplier_id) ON DELETE SET NULL,
  wallet_id UUID REFERENCES wallets(wallet_id) ON DELETE SET NULL,
  user_id UUID NOT NULL REFERENCES profiles(user_id) ON DELETE RESTRICT,
  event_type event_type_enum NOT NULL,
  amount DECIMAL(15,2) NOT NULL CHECK (amount > 0),
  payment_method payment_method_enum NOT NULL,
  description TEXT,
  attachment_url VARCHAR(512),
  status event_status_enum NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 12. Transaction Meta (Dynamic Fields Engine)
CREATE TABLE transaction_meta (
  meta_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  event_id UUID NOT NULL REFERENCES financial_events(event_id) ON DELETE CASCADE,
  meta_key VARCHAR(255) NOT NULL,
  meta_value TEXT NOT NULL,
  CONSTRAINT unique_meta_node UNIQUE (event_id, meta_key)
);

-- 13. Audit Logs
CREATE TABLE audit_logs (
  audit_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(user_id) ON DELETE SET NULL,
  entity_type VARCHAR(100) NOT NULL,
  entity_id UUID NOT NULL,
  action VARCHAR(100) NOT NULL,
  old_value JSONB,
  new_value JSONB,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Performance Indexes
CREATE INDEX idx_events_project ON financial_events(project_id, phase_id, category_id);
CREATE INDEX idx_events_status ON financial_events(event_type, status);
CREATE INDEX idx_meta_lookup ON transaction_meta(event_id, meta_key);
CREATE INDEX idx_audit ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_docs_expiry ON documents(expiry_date);

-- Seed a default company
INSERT INTO companies (company_id, company_name) VALUES
('00000000-0000-0000-0000-000000000000', 'Default Company');

-- Seed project templates
INSERT INTO project_templates (project_type, default_phases) VALUES
('Residential', '[
  {"name": "التراخيص والأوراق الرسمية", "order": 1},
  {"name": "الحفر والإحلال", "order": 2},
  {"name": "الأساسات والخرسانة", "order": 3},
  {"name": "الهيكل الإنشائي", "order": 4},
  {"name": "أعمال الطوب والمباني", "order": 5},
  {"name": "الكهرباء", "order": 6},
  {"name": "السباكة", "order": 7},
  {"name": "التشطيبات", "order": 8},
  {"name": "اللاندسكيب", "order": 9}
]'),
('Industrial', '[
  {"name": "التراخيص الصناعية", "order": 1},
  {"name": "الدراسة البيئية", "order": 2},
  {"name": "الإنشاءات والمباني", "order": 3},
  {"name": "استيراد الماكينات", "order": 4},
  {"name": "الجمارك والنقل", "order": 5},
  {"name": "تركيب خطوط الإنتاج", "order": 6},
  {"name": "التشغيل التجريبي", "order": 7},
  {"name": "شهادات الجودة", "order": 8},
  {"name": "تدريب العمالة", "order": 9}
]'),
('Farm', '[
  {"name": "تجهيز التربة", "order": 1},
  {"name": "شبكات الري", "order": 2},
  {"name": "البنية التحتية", "order": 3},
  {"name": "المعدات الزراعية", "order": 4},
  {"name": "التشغيل والإنتاج", "order": 5}
]'),
('Hotel', '[
  {"name": "التراخيص", "order": 1},
  {"name": "الإنشاءات", "order": 2},
  {"name": "التأثيث والفرش", "order": 3},
  {"name": "التجهيزات", "order": 4},
  {"name": "التشغيل التجريبي", "order": 5}
]'),
('Mall', '[
  {"name": "التراخيص", "order": 1},
  {"name": "الإنشاءات", "order": 2},
  {"name": "المرافق والخدمات", "order": 3},
  {"name": "تجهيز المحلات", "order": 4},
  {"name": "الافتتاح والتشغيل", "order": 5}
]'),
('Custom', '[]');