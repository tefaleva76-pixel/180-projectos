-- Enable RLS on all tables
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE phases ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE budgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE financial_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE transaction_meta ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Companies: visible to users in same company
CREATE POLICY companies_access ON companies
  FOR ALL USING (
    company_id IN (SELECT company_id FROM profiles WHERE user_id = auth.uid())
  );

-- Profiles: users can view profiles in same company
CREATE POLICY profiles_access ON profiles
  FOR ALL USING (
    company_id IN (SELECT company_id FROM profiles WHERE user_id = auth.uid())
  );

-- Projects: filtered by company_id
CREATE POLICY projects_access ON projects
  FOR ALL USING (
    company_id IN (SELECT company_id FROM profiles WHERE user_id = auth.uid())
  );

-- Phases: via project ownership
CREATE POLICY phases_access ON phases
  FOR ALL USING (
    project_id IN (SELECT project_id FROM projects WHERE company_id IN (SELECT company_id FROM profiles WHERE user_id = auth.uid()))
  );

-- Categories: via project ownership
CREATE POLICY categories_access ON categories
  FOR ALL USING (
    project_id IN (SELECT project_id FROM projects WHERE company_id IN (SELECT company_id FROM profiles WHERE user_id = auth.uid()))
  );

-- Suppliers: by company
CREATE POLICY suppliers_access ON suppliers
  FOR ALL USING (
    company_id IN (SELECT company_id FROM profiles WHERE user_id = auth.uid())
  );

-- Wallets: by company
CREATE POLICY wallets_access ON wallets
  FOR ALL USING (
    company_id IN (SELECT company_id FROM profiles WHERE user_id = auth.uid())
  );

-- Budgets: via project ownership
CREATE POLICY budgets_access ON budgets
  FOR ALL USING (
    project_id IN (SELECT project_id FROM projects WHERE company_id IN (SELECT company_id FROM profiles WHERE user_id = auth.uid()))
  );

-- Documents: via project ownership
CREATE POLICY documents_access ON documents
  FOR ALL USING (
    project_id IN (SELECT project_id FROM projects WHERE company_id IN (SELECT company_id FROM profiles WHERE user_id = auth.uid()))
  );

-- Financial events: via project ownership
CREATE POLICY financial_events_access ON financial_events
  FOR ALL USING (
    project_id IN (SELECT project_id FROM projects WHERE company_id IN (SELECT company_id FROM profiles WHERE user_id = auth.uid()))
  );

-- Transaction meta: via event ownership
CREATE POLICY transaction_meta_access ON transaction_meta
  FOR ALL USING (
    event_id IN (SELECT event_id FROM financial_events WHERE project_id IN (SELECT project_id FROM projects WHERE company_id IN (SELECT company_id FROM profiles WHERE user_id = auth.uid())))
  );
