import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Loader2, Plus, Edit2, Trash2 } from 'lucide-react';
import type { Phase, Category, Supplier } from '@/types';

const ManagementPage: React.FC = () => {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'phases' | 'categories' | 'suppliers'>('phases');
  const [loading, setLoading] = useState(true);
  
  // Data
  const [projects, setProjects] = useState<{project_id: string, project_name: string}[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  
  const [phases, setPhases] = useState<Phase[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);

  useEffect(() => {
    if (!profile) return;
    if (profile.role !== 'Owner') {
      toast.error('ليس لديك صلاحية للوصول إلى هذه الصفحة');
      return;
    }
    fetchProjects();
    fetchSuppliers();
  }, [profile]);

  useEffect(() => {
    if (selectedProjectId) {
      fetchPhases();
      fetchCategories();
    }
  }, [selectedProjectId]);

  const fetchProjects = async () => {
    const { data } = await supabase.from('projects').select('project_id, project_name').eq('company_id', profile!.company_id);
    setProjects(data || []);
    if (data && data.length > 0) {
      setSelectedProjectId(data[0].project_id);
    }
    setLoading(false);
  };

  const fetchPhases = async () => {
    const { data } = await supabase.from('phases').select('*').eq('project_id', selectedProjectId).order('phase_order');
    setPhases(data || []);
  };

  const fetchCategories = async () => {
    const { data } = await supabase.from('categories').select('*').eq('project_id', selectedProjectId);
    setCategories(data || []);
  };

  const fetchSuppliers = async () => {
    const { data } = await supabase.from('suppliers').select('*').eq('company_id', profile!.company_id);
    setSuppliers(data || []);
  };

  const handleDelete = async (table: string, idField: string, id: string) => {
    if (!window.confirm('هل أنت متأكد من الحذف؟ سيتم حذف جميع البيانات المرتبطة نهائياً.')) return;
    
    setLoading(true);
    const { error } = await supabase.from(table).delete().eq(idField, id);
    if (error) {
      toast.error(`فشل الحذف: ${error.message}`);
    } else {
      toast.success('تم الحذف بنجاح');
      if (table === 'phases') fetchPhases();
      if (table === 'categories') fetchCategories();
      if (table === 'suppliers') fetchSuppliers();
    }
    setLoading(false);
  };

  if (profile?.role !== 'Owner') {
    return <div className="p-6 text-center text-muted-foreground">غير مصرح بالدخول</div>;
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-foreground">إدارة المشروع</h1>
        
        {/* Project Selector */}
        {(activeTab === 'phases' || activeTab === 'categories') && (
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">المشروع:</span>
            <select 
              value={selectedProjectId} 
              onChange={e => setSelectedProjectId(e.target.value)}
              className="px-3 py-2 rounded-lg border border-border bg-white text-sm focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50"
            >
              {projects.map(p => (
                <option key={p.project_id} value={p.project_id}>{p.project_name}</option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-border pb-px">
        {[
          { id: 'phases', label: 'المراحل' },
          { id: 'categories', label: 'الفئات' },
          { id: 'suppliers', label: 'الموردين' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-5 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-[2px] ${
              activeTab === tab.id 
                ? 'border-[#3ECFCF] text-[#1A1A1A]' 
                : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-[#3ECFCF]" />
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-border shadow-sm overflow-hidden">
          
          {/* Header Row */}
          <div className="flex items-center justify-between p-4 border-b border-border bg-muted/30">
            <h3 className="font-bold text-foreground">
              {activeTab === 'phases' ? 'إدارة المراحل' : activeTab === 'categories' ? 'إدارة الفئات' : 'إدارة الموردين'}
            </h3>
            <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#1A1A1A] text-white text-sm font-medium hover:opacity-90 transition-opacity">
              <Plus size={16} />
              <span>إضافة جديد</span>
            </button>
          </div>

          {/* Data List */}
          <div className="divide-y divide-border">
            {activeTab === 'phases' && phases.length === 0 && <div className="p-8 text-center text-muted-foreground">لا توجد مراحل</div>}
            {activeTab === 'phases' && phases.map(phase => (
              <div key={phase.phase_id} className="flex items-center justify-between p-4 hover:bg-muted/20 transition-colors">
                <div className="flex items-center gap-4">
                  <span className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-sm font-bold text-muted-foreground">
                    {phase.phase_order}
                  </span>
                  <div>
                    <div className="font-semibold text-foreground">{phase.phase_name}</div>
                    <div className="text-xs text-muted-foreground">{phase.status}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 text-muted-foreground hover:text-[#3ECFCF] hover:bg-[#3ECFCF]/10 rounded-lg transition-colors">
                    <Edit2 size={16} />
                  </button>
                  <button 
                    onClick={() => handleDelete('phases', 'phase_id', phase.phase_id)}
                    className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}

            {activeTab === 'categories' && categories.length === 0 && <div className="p-8 text-center text-muted-foreground">لا توجد فئات</div>}
            {activeTab === 'categories' && categories.map(cat => (
              <div key={cat.category_id} className="flex items-center justify-between p-4 hover:bg-muted/20 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                    <div className="w-4 h-4 rounded-full" style={{ backgroundColor: cat.color }} />
                  </div>
                  <span className="font-semibold text-foreground">{cat.category_name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 text-muted-foreground hover:text-[#3ECFCF] hover:bg-[#3ECFCF]/10 rounded-lg transition-colors">
                    <Edit2 size={16} />
                  </button>
                  <button 
                    onClick={() => handleDelete('categories', 'category_id', cat.category_id)}
                    className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}

            {activeTab === 'suppliers' && suppliers.length === 0 && <div className="p-8 text-center text-muted-foreground">لا يوجد موردين</div>}
            {activeTab === 'suppliers' && suppliers.map(sup => (
              <div key={sup.supplier_id} className="flex items-center justify-between p-4 hover:bg-muted/20 transition-colors">
                <div>
                  <div className="font-semibold text-foreground">{sup.supplier_name}</div>
                  <div className="text-sm text-muted-foreground mt-1 flex gap-4">
                    {sup.phone && <span>📞 {sup.phone}</span>}
                    {sup.tax_number && <span>📑 الضريبي: {sup.tax_number}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 text-muted-foreground hover:text-[#3ECFCF] hover:bg-[#3ECFCF]/10 rounded-lg transition-colors">
                    <Edit2 size={16} />
                  </button>
                  <button 
                    onClick={() => handleDelete('suppliers', 'supplier_id', sup.supplier_id)}
                    className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ManagementPage;