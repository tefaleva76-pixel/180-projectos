import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import type { FinancialEvent, Project, Phase, Category } from '@/types';
import { toast } from 'sonner';
import { Plus, Wallet, Receipt, AlertTriangle, BarChart3, Loader2, Edit, Trash2 } from 'lucide-react';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
} from 'recharts';

const COLORS = ['#3ECFCF', '#10B981', '#F59E0B', '#EF4444', '#6366F1', '#EC4899', '#8B5CF6', '#14B8A6'];

const DashboardPage: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [project, setProject] = useState<Project | null>(null);
  const [events, setEvents] = useState<FinancialEvent[]>([]);
  const [phases, setPhases] = useState<Phase[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [visibleCount, setVisibleCount] = useState(15);

  const fetchData = useCallback(async () => {
    if (!projectId || !profile) return;
    
    // Load from cache for instant rendering
    const cacheKey = `dash_cache_${projectId}`;
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        setProject(parsed.project);
        setEvents(parsed.events);
        setPhases(parsed.phases);
        setCategories(parsed.categories);
        setLoading(false);
      } catch (e) {
        console.error('Cache parsing failed');
      }
    } else {
      setLoading(true);
    }

    const [projectRes, eventsRes, phasesRes, categoriesRes] = await Promise.all([
      supabase.from('projects').select('*').eq('project_id', projectId).eq('company_id', profile.company_id).single(),
      supabase.from('financial_events').select('*, phase:phases(phase_name), category:categories(category_name)').eq('project_id', projectId).order('created_at', { ascending: false }),
      supabase.from('phases').select('*').eq('project_id', projectId).order('phase_order', { ascending: true }),
      supabase.from('categories').select('*').eq('project_id', projectId),
    ]);

    if (projectRes.error) { 
      if (!cached) { toast.error('فشل في تحميل المشروع'); navigate('/portfolio'); }
      return; 
    }
    
    const freshData = {
      project: projectRes.data,
      events: (eventsRes.data || []) as FinancialEvent[],
      phases: phasesRes.data || [],
      categories: categoriesRes.data || []
    };
    
    setProject(freshData.project);
    setEvents(freshData.events);
    setPhases(freshData.phases);
    setCategories(freshData.categories);
    
    localStorage.setItem(cacheKey, JSON.stringify(freshData));
    setLoading(false);
  }, [projectId, profile, navigate]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Realtime subscription
  useEffect(() => {
    if (!projectId) return;
    const channel = supabase
      .channel(`events-${projectId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'financial_events', filter: `project_id=eq.${projectId}` }, () => {
        fetchData();
      })
      .subscribe();
  const handleDeleteEvent = async (eventId: string) => {
    try {
      const { error } = await supabase.from('financial_events').delete().eq('event_id', eventId);
      if (error) throw error;
      toast.success('تم حذف الحدث بنجاح');
      fetchData();
    } catch (err: any) {
      toast.error('فشل في حذف الحدث: ' + err.message);
    }
  };
    return () => { supabase.removeChannel(channel); };
  }, [projectId, fetchData]);

  const approvedEvents = events.filter(e => e.status === 'Approved');
  const totalExpenses = approvedEvents.reduce((sum, e) => sum + Number(e.amount), 0);
  const pendingCount = events.filter(e => e.status === 'Pending').length;
  const totalInvoices = events.filter(e => e.attachment_url).length;
  const budgetPct = project && Number(project.budget) > 0 ? Math.min((totalExpenses / Number(project.budget)) * 100, 100) : 0;

  // Pie chart data: expenses by category
  const categoryMap: Record<string, number> = {};
  for (const e of approvedEvents) {
    const catName = e.category?.category_name || 'غير محدد';
    categoryMap[catName] = (categoryMap[catName] || 0) + Number(e.amount);
  }
  const pieData = Object.entries(categoryMap).map(([name, value]) => ({ name, value }));

  // Bar chart data: planned vs actual by phase
  const barData = phases.map(phase => {
    const phaseActual = approvedEvents
      .filter(e => e.phase_id === phase.phase_id)
      .reduce((sum, e) => sum + Number(e.amount), 0);
    return {
      name: phase.phase_name,
      actual: phaseActual,
      planned: 0,
    };
  });

  const handleDeleteEvent = async (eventId: string) => {
    try {
      const { error } = await supabase.from('financial_events').delete().eq('event_id', eventId);
      if (error) throw error;
      toast.success('تم حذف الحدث بنجاح');
      fetchData();
    } catch (err: any) {
      toast.error('فشل في حذف الحدث: ' + err.message);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 size={40} className="animate-spin text-[#3ECFCF]" />
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{project?.project_name}</h1>
          <p className="text-sm text-muted-foreground">لوحة التحكم المالي</p>
        </div>
        <button
          onClick={() => navigate(`/add-event/${projectId}`)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-white font-medium transition-all hover:opacity-90 shadow-sm"
          style={{ backgroundColor: '#1A1A1A' }}
        >
          <Plus size={18} />
          <span>إضافة حدث مالي</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-2xl border border-border p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">إجمالي المصروفات</span>
            <Wallet size={18} className="text-[#3ECFCF]" />
          </div>
          <div className="text-2xl font-bold text-foreground">{totalExpenses.toLocaleString()} {project?.currency}</div>
        </div>
        <div className="bg-white rounded-2xl border border-border p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">نسبة الميزانية المستهلكة</span>
            <BarChart3 size={18} className="text-[#10B981]" />
          </div>
          <div className="text-2xl font-bold text-foreground">{budgetPct.toFixed(1)}%</div>
          <div className="w-full h-1.5 bg-muted rounded-full mt-2 overflow-hidden">
            <div className="h-full rounded-full bg-[#10B981] transition-all" style={{ width: `${budgetPct}%` }} />
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-border p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">حركات معلقة للاعتماد</span>
            <AlertTriangle size={18} className="text-[#F59E0B]" />
          </div>
          <div className="text-2xl font-bold text-foreground">{pendingCount}</div>
        </div>
        <div className="bg-white rounded-2xl border border-border p-5 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">إجمالي الفواتير</span>
            <Receipt size={18} className="text-[#6366F1]" />
          </div>
          <div className="text-2xl font-bold text-foreground">{totalInvoices}</div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-6">
        <div className="bg-white rounded-2xl border border-border p-5 shadow-sm min-w-0">
          <h3 className="text-lg font-bold text-foreground mb-4">المصروفات حسب الفئة</h3>
          <div className="h-64 w-full overflow-x-auto overflow-y-hidden">
            <div className="min-w-[300px] h-full">
              {pieData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={4} dataKey="value">
                      {pieData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <RechartsTooltip formatter={(value: number) => `${Number(value).toLocaleString()} EGP`} />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">لا توجد بيانات</div>
              )}
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-border p-5 shadow-sm min-w-0">
          <h3 className="text-lg font-bold text-foreground mb-4">الميزانية المخططة مقابل الفعلي</h3>
          <div className="h-64 w-full overflow-x-auto overflow-y-hidden">
            <div className="min-w-[400px] h-full">
              {barData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={barData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <RechartsTooltip formatter={(value: number) => `${Number(value).toLocaleString()}`} />
                    <Bar dataKey="actual" fill="#3ECFCF" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">لا توجد بيانات</div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Activity Feed */}
      <div className="bg-white rounded-2xl border border-border p-5 shadow-sm">
        <h3 className="text-lg font-bold text-foreground mb-4">نبض الموقع اللحظي</h3>
        <div className="space-y-3">
          {events.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">لا توجد حركات مالية بعد</div>
          ) : (
            <>
              {events.slice(0, visibleCount).map(event => {
                const canEdit = profile?.role === 'Owner' || (profile?.role === 'Site_Engineer' && event.status === 'Pending' && event.user_id === profile.user_id);
                return (
                  <div key={event.event_id} className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 rounded-xl bg-muted/20 border border-border/50 hover:bg-muted/40 transition-colors group">
                    <div className="flex items-start sm:items-center gap-3 flex-1 min-w-0">
                      <div className={`w-3 h-3 rounded-full shrink-0 mt-1 sm:mt-0 ${
                        event.status === 'Approved' ? 'bg-[#10B981]' : event.status === 'Pending' ? 'bg-[#F59E0B]' : 'bg-[#EF4444]'
                      }`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                          <span className="text-sm font-semibold text-foreground">{event.event_type}</span>
                          <span className="text-sm font-bold text-[#3ECFCF]">{Number(event.amount).toLocaleString()} EGP</span>
                        </div>
                        <div className="text-xs text-muted-foreground mt-1 truncate">
                          {event.phase?.phase_name} · {event.category?.category_name} {event.description ? `· ${event.description}` : ''}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 mt-2 sm:mt-0 border-t sm:border-0 border-border/50 pt-2 sm:pt-0">
                      <span className={`text-xs font-medium px-2.5 py-1 rounded-lg ${
                        event.status === 'Approved' ? 'bg-[#10B981]/10 text-[#10B981]' :
                        event.status === 'Pending' ? 'bg-[#F59E0B]/10 text-[#F59E0B]' :
                        'bg-[#EF4444]/10 text-[#EF4444]'
                      }`}>
                        {event.status === 'Approved' ? 'معتمد' : event.status === 'Pending' ? 'معلق' : 'مرفوض'}
                      </span>
                      
                      {canEdit && (
                        <button
                          onClick={() => {
                            if (window.confirm('هل أنت متأكد من الحذف؟ سيتم حذف جميع البيانات المرتبطة نهائياً.')) {
                              handleDeleteEvent(event.event_id);
                            }
                          }}
                          className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-md transition-colors opacity-100 sm:opacity-0 sm:group-hover:opacity-100"
                          title="حذف"
                        >
                          <Trash2 size={16} />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
              {events.length > visibleCount && (
                <button 
                  onClick={() => setVisibleCount(v => v + 15)}
                  className="w-full py-3 mt-4 text-sm font-medium text-foreground bg-muted/50 hover:bg-muted rounded-xl transition-colors"
                >
                  تحميل المزيد
                </button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
