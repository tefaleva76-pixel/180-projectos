import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import type { FinancialEvent } from '@/types';
import { Loader2, Download } from 'lucide-react';
import { toast } from 'sonner';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, LineChart, Line
} from 'recharts';

const COLORS = ['#3ECFCF', '#10B981', '#F59E0B', '#EF4444', '#6366F1', '#EC4899', '#8B5CF6', '#14B8A6'];

const ReportsPage: React.FC = () => {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'charts' | 'table' | 'pdf'>('charts');
  const [projects, setProjects] = useState<{project_id: string, project_name: string}[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [events, setEvents] = useState<FinancialEvent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    fetchProjects();
  }, [profile]);

  useEffect(() => {
    if (selectedProjectId) {
      fetchEvents();
    }
  }, [selectedProjectId]);

  const fetchProjects = async () => {
    const { data } = await supabase.from('projects').select('project_id, project_name').eq('company_id', profile!.company_id);
    setProjects(data || []);
    if (data && data.length > 0) setSelectedProjectId(data[0].project_id);
    setLoading(false);
  };

  const fetchEvents = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('financial_events')
      .select('*, phase:phases(phase_name), category:categories(category_name), profile:profiles(name)')
      .eq('project_id', selectedProjectId)
      .eq('status', 'Approved')
      .order('created_at', { ascending: true });
    setEvents((data || []) as FinancialEvent[]);
    setLoading(false);
  };

  // Process data for charts
  const categoryMap: Record<string, number> = {};
  const phaseMap: Record<string, number> = {};
  const timelineMap: Record<string, number> = {};

  events.forEach(e => {
    const cat = e.category?.category_name || 'غير محدد';
    const phase = e.phase?.phase_name || 'غير محدد';
    const date = new Date(e.created_at).toLocaleDateString('ar-EG', { month: 'short', year: 'numeric' });
    
    categoryMap[cat] = (categoryMap[cat] || 0) + Number(e.amount);
    phaseMap[phase] = (phaseMap[phase] || 0) + Number(e.amount);
    timelineMap[date] = (timelineMap[date] || 0) + Number(e.amount);
  });

  const pieData = Object.entries(categoryMap).map(([name, value]) => ({ name, value }));
  const barData = Object.entries(phaseMap).map(([name, value]) => ({ name, value }));
  const lineData = Object.entries(timelineMap).map(([name, value]) => ({ name, value }));

  const exportPDF = () => {
    // In a real app, we would use a library like jspdf to generate the PDF
    // For this prototype, we'll use browser native printing which produces high quality PDF via "Save as PDF"
    setTimeout(() => {
      window.print();
    }, 100);
  };

  const handleDeleteEvent = async (eventId: string) => {
    try {
      const { error } = await supabase.from('financial_events').delete().eq('event_id', eventId);
      if (error) throw error;
      toast.success('تم حذف الحدث بنجاح');
      fetchEvents();
    } catch (err: any) {
      toast.error('فشل في حذف الحدث: ' + err.message);
    }
  };

  const totalExpenses = events.reduce((sum, e) => sum + Number(e.amount), 0);
  const selectedProjectName = projects.find(p => p.project_id === selectedProjectId)?.project_name || 'غير محدد';

  if (profile?.role === 'Site_Engineer') {
    return <div className="p-6 text-center text-muted-foreground">غير مصرح بالدخول</div>;
  }

  return (
    <>
      <div className="print:hidden p-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-foreground">التقارير</h1>
        
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">المشروع:</span>
          <select 
            value={selectedProjectId} 
            onChange={e => setSelectedProjectId(e.target.value)}
            className="px-3 py-2 rounded-lg border border-border bg-white text-sm focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50"
          >
            {projects.map(p => (
              <option key={p.project_id} value={p.project_id}>{p.project_name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-border pb-px">
        {[
          { id: 'charts', label: 'لوحة حية' },
          { id: 'table', label: 'تقرير مفصل' },
          { id: 'pdf', label: 'تصدير PDF' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-5 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-[2px] ${
              activeTab === tab.id 
                ? 'border-[#3ECFCF] text-[#1A1A1A]' 
                : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-[#3ECFCF]" />
        </div>
      ) : activeTab === 'charts' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="bg-white rounded-2xl border border-border p-5 shadow-sm">
            <h3 className="text-lg font-bold text-foreground mb-4">المصروفات حسب الفئة</h3>
            <div className="h-64">
              {pieData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={4} dataKey="value">
                      {pieData.map((_, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                    </Pie>
                    <RechartsTooltip formatter={(value: number) => `${Number(value).toLocaleString()} EGP`} />
                  </PieChart>
                </ResponsiveContainer>
              ) : <div className="flex items-center justify-center h-full text-muted-foreground">لا توجد بيانات</div>}
            </div>
          </div>
          
          <div className="bg-white rounded-2xl border border-border p-5 shadow-sm">
            <h3 className="text-lg font-bold text-foreground mb-4">المصروفات حسب المرحلة</h3>
            <div className="h-64">
              {barData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={barData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <RechartsTooltip formatter={(value: number) => `${Number(value).toLocaleString()}`} />
                    <Bar dataKey="value" fill="#3ECFCF" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : <div className="flex items-center justify-center h-full text-muted-foreground">لا توجد بيانات</div>}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-border p-5 shadow-sm lg:col-span-2">
            <h3 className="text-lg font-bold text-foreground mb-4">التوجه الزمني للمصروفات</h3>
            <div className="h-64">
              {lineData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={lineData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <RechartsTooltip formatter={(value: number) => `${Number(value).toLocaleString()}`} />
                    <Line type="monotone" dataKey="value" stroke="#3ECFCF" strokeWidth={3} dot={{ r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              ) : <div className="flex items-center justify-center h-full text-muted-foreground">لا توجد بيانات</div>}
            </div>
          </div>
        </div>
      ) : activeTab === 'table' ? (
        <div className="bg-white rounded-2xl border border-border shadow-sm overflow-hidden overflow-x-auto">
          <table className="w-full min-w-[800px] text-right">
            <thead className="bg-muted/30">
              <tr>
                <th className="px-4 py-3 text-sm font-semibold text-foreground border-b">التاريخ</th>
                <th className="px-4 py-3 text-sm font-semibold text-foreground border-b">النوع</th>
                <th className="px-4 py-3 text-sm font-semibold text-foreground border-b">المبلغ</th>
                <th className="px-4 py-3 text-sm font-semibold text-foreground border-b">المرحلة</th>
                <th className="px-4 py-3 text-sm font-semibold text-foreground border-b">الفئة</th>
                <th className="px-4 py-3 text-sm font-semibold text-foreground border-b">المستخدم</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {events.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">لا توجد بيانات</td>
                </tr>
              ) : (
                events.map(event => (
                  <tr key={event.event_id} className="hover:bg-muted/20">
                    <td className="px-4 py-3 text-sm text-foreground">{new Date(event.created_at).toLocaleDateString('ar-EG')}</td>
                    <td className="px-4 py-3 text-sm font-medium text-foreground">{event.event_type}</td>
                    <td className="px-4 py-3 text-sm font-bold text-[#3ECFCF]">{Number(event.amount).toLocaleString()} EGP</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{event.phase?.phase_name}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{event.category?.category_name}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{event.profile?.name}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-border p-8 shadow-sm text-center max-w-xl mx-auto">
          <img src="/ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico" alt="Logo" className="h-24 object-contain mx-auto mb-6" />
          <h2 className="text-xl font-bold text-foreground mb-2">تصدير تقرير المشروع</h2>
          <p className="text-muted-foreground mb-8">
            سيتم إنشاء تقرير PDF احترافي يحتوي على ملخص المصروفات والميزانية مع التفاصيل الكاملة.
          </p>
          <button 
            onClick={exportPDF}
            className="flex items-center justify-center gap-2 mx-auto px-6 py-3 rounded-xl bg-[#1A1A1A] text-white font-semibold hover:opacity-90 transition-opacity"
          >
            <Download size={18} />
            <span>استخراج كشف الحساب PDF</span>
          </button>
        </div>
      )}
      </div>

      {/* Printable Report View */}
      <div className="hidden print:block p-8" dir="rtl">
        <div className="text-center mb-8 border-b border-border pb-6">
          <img src="/ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico" alt="180° ProjectOS Logo" className="h-32 object-contain mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-foreground mb-2">كشف حساب المشروع</h1>
          <p className="text-xl text-muted-foreground">{selectedProjectName}</p>
          <p className="text-sm text-muted-foreground mt-2">تاريخ التقرير: {new Date().toLocaleDateString('ar-EG')}</p>
        </div>

        <div className="mb-8 grid grid-cols-2 gap-4">
          <div className="border border-border p-4 rounded-xl">
            <h3 className="text-sm font-semibold text-muted-foreground mb-1">إجمالي المصروفات</h3>
            <p className="text-2xl font-bold text-[#3ECFCF]">{totalExpenses.toLocaleString()} EGP</p>
          </div>
          <div className="border border-border p-4 rounded-xl">
            <h3 className="text-sm font-semibold text-muted-foreground mb-1">عدد الحركات المالية</h3>
            <p className="text-2xl font-bold">{events.length}</p>
          </div>
        </div>

        <h3 className="text-lg font-bold text-foreground mb-4">التفاصيل المالية</h3>
        <table className="w-full text-right border-collapse border border-border">
          <thead className="bg-muted/30">
            <tr>
              <th className="border border-border px-3 py-2 text-sm font-semibold">التاريخ</th>
              <th className="border border-border px-3 py-2 text-sm font-semibold">النوع</th>
              <th className="border border-border px-3 py-2 text-sm font-semibold">المبلغ</th>
              <th className="border border-border px-3 py-2 text-sm font-semibold">المرحلة</th>
              <th className="border border-border px-3 py-2 text-sm font-semibold">الفئة</th>
              <th className="border border-border px-3 py-2 text-sm font-semibold">المستخدم</th>
            </tr>
          </thead>
          <tbody>
            {events.map(event => (
              <tr key={event.event_id}>
                <td className="border border-border px-3 py-2 text-sm">{new Date(event.created_at).toLocaleDateString('ar-EG')}</td>
                <td className="border border-border px-3 py-2 text-sm">{event.event_type}</td>
                <td className="border border-border px-3 py-2 text-sm font-bold text-[#3ECFCF]">{Number(event.amount).toLocaleString()} EGP</td>
                <td className="border border-border px-3 py-2 text-sm">{event.phase?.phase_name}</td>
                <td className="border border-border px-3 py-2 text-sm">{event.category?.category_name}</td>
                <td className="border border-border px-3 py-2 text-sm">{event.profile?.name}</td>
              </tr>
            ))}
            {events.length === 0 && (
              <tr>
                <td colSpan={6} className="border border-border px-3 py-4 text-center text-muted-foreground">لا توجد بيانات</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default ReportsPage;