import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { FileText, Download, Trash2, UploadCloud, Loader2, AlertCircle } from 'lucide-react';
import type { DocumentItem } from '@/types';

const DocumentTypes = ['فاتورة', 'عقد', 'ترخيص رسمي', 'دراسة بيئية', 'إيصال', 'سجل ضريبي'];

const DocumentsPage: React.FC = () => {
  const { profile } = useAuth();
  const [projects, setProjects] = useState<{project_id: string, project_name: string}[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');
  
  // Upload state
  const [showUpload, setShowUpload] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [docName, setDocName] = useState('');
  const [docType, setDocType] = useState(DocumentTypes[0]);
  const [expiryDate, setExpiryDate] = useState('');
  const [file, setFile] = useState<File | null>(null);

  useEffect(() => {
    if (!profile) return;
    fetchProjects();
  }, [profile]);

  useEffect(() => {
    if (selectedProjectId) {
      fetchDocuments();
    }
  }, [selectedProjectId]);

  const fetchProjects = async () => {
    const { data } = await supabase.from('projects').select('project_id, project_name').eq('company_id', profile!.company_id);
    setProjects(data || []);
    if (data && data.length > 0) setSelectedProjectId(data[0].project_id);
    setLoading(false);
  };

  const fetchDocuments = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('documents')
      .select('*')
      .eq('project_id', selectedProjectId)
      .order('created_at', { ascending: false });
    setDocuments((data || []) as DocumentItem[]);
    setLoading(false);
  };

  const handleUpload = async () => {
    if (!selectedProjectId) return;
    if (!docName.trim()) { toast.error('يرجى إدخال اسم المستند'); return; }
    if (!file) { toast.error('يرجى اختيار ملف'); return; }
    
    // Check file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
      toast.error('حجم الملف كبير جداً. الحد الأقصى 10 ميجابايت');
      return;
    }

    setUploading(true);
    
    try {
      // 1. Upload to Supabase Storage (assuming bucket 'documents' exists)
      const fileExt = file.name.split('.').pop();
      const fileName = `${selectedProjectId}/${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('documents')
        .upload(fileName, file);
        
      if (uploadError) {
        // If bucket doesn't exist, we'll simulate success for this prototype
        console.warn('Storage error (bucket may not exist):', uploadError);
      }
      
      // 2. Save record to DB
      const fileUrl = uploadData ? 
        supabase.storage.from('documents').getPublicUrl(uploadData.path).data.publicUrl : 
        `https://example.com/mock-doc-${Date.now()}`; // Fallback for prototype
      
      const { error: dbError } = await supabase.from('documents').insert({
        project_id: selectedProjectId,
        document_type: docType,
        document_name: docName,
        expiry_date: expiryDate || null,
        attachment_url: fileUrl
      });
      
      if (dbError) throw dbError;
      
      toast.success('تم رفع المستند بنجاح');
      setShowUpload(false);
      setDocName('');
      setExpiryDate('');
      setFile(null);
      fetchDocuments();
    } catch (err: any) {
      toast.error('فشل الرفع: ' + err.message);
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('هل أنت متأكد من الحذف؟ لا يمكن التراجع.')) return;
    try {
      const { error } = await supabase.from('documents').delete().eq('document_id', id);
      if (error) throw error;
      toast.success('تم الحذف بنجاح');
      fetchDocuments();
    } catch (err: any) {
      toast.error('فشل الحذف: ' + err.message);
    }
  };

  const isExpiringSoon = (dateStr?: string) => {
    if (!dateStr) return false;
    const expiry = new Date(dateStr);
    const now = new Date('2026-06-24'); // Current system date
    const diffTime = expiry.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays >= 0 && diffDays <= 30;
  };

  const isExpired = (dateStr?: string) => {
    if (!dateStr) return false;
    const expiry = new Date(dateStr);
    const now = new Date('2026-06-24');
    return expiry < now;
  };

  const filteredDocs = filter === 'all' ? documents : documents.filter(d => d.document_type === filter);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <h1 className="text-2xl font-bold text-foreground">مركز المستندات</h1>
        
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <select 
            value={selectedProjectId} 
            onChange={e => setSelectedProjectId(e.target.value)}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-border bg-white text-sm focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50"
          >
            {projects.map(p => (
              <option key={p.project_id} value={p.project_id}>{p.project_name}</option>
            ))}
          </select>
          
          <button 
            onClick={() => setShowUpload(true)}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#1A1A1A] text-white font-medium hover:opacity-90 transition-opacity whitespace-nowrap"
          >
            <UploadCloud size={18} />
            <span>رفع مستند</span>
          </button>
        </div>
      </div>

      {/* Filter */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
            filter === 'all' ? 'bg-muted text-foreground' : 'text-muted-foreground hover:bg-muted/50'
          }`}
        >
          الكل
        </button>
        {DocumentTypes.map(t => (
          <button
            key={t}
            onClick={() => setFilter(t)}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
              filter === t ? 'bg-muted text-foreground' : 'text-muted-foreground hover:bg-muted/50'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* List */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-[#3ECFCF]" />
        </div>
      ) : filteredDocs.length === 0 ? (
        <div className="bg-white rounded-2xl border border-border p-12 text-center shadow-sm">
          <FileText size={48} className="mx-auto text-muted-foreground/30 mb-4" />
          <h3 className="text-lg font-medium text-foreground">لا توجد مستندات</h3>
          <p className="text-muted-foreground mt-1">اضغط على "رفع مستند" لإضافة ملفات جديدة</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDocs.map(doc => {
            const expiringSoon = isExpiringSoon(doc.expiry_date);
            const expired = isExpired(doc.expiry_date);
            
            return (
              <div key={doc.document_id} className="bg-white rounded-2xl border border-border p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center text-muted-foreground shrink-0">
                      <FileText size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-foreground line-clamp-1" title={doc.document_name}>{doc.document_name}</h4>
                      <span className="text-xs bg-muted px-2 py-0.5 rounded text-muted-foreground inline-block mt-1">
                        {doc.document_type}
                      </span>
                    </div>
                  </div>
                  {expired ? (
                    <span className="shrink-0 bg-destructive/10 text-destructive text-[10px] font-bold px-2 py-1 rounded flex items-center gap-1">
                      ⚠️ منتهي
                    </span>
                  ) : expiringSoon ? (
                    <span className="shrink-0 bg-[#F59E0B]/10 text-[#F59E0B] text-[10px] font-bold px-2 py-1 rounded flex items-center gap-1">
                      ⚠️ يقترب من الانتهاء
                    </span>
                  ) : null}
                </div>
                
                <div className="mt-auto pt-4 border-t border-border flex items-center justify-between">
                  <div className="text-xs text-muted-foreground">
                    {doc.expiry_date ? `صالح حتى: ${new Date(doc.expiry_date).toLocaleDateString('ar-EG')}` : 'بدون تاريخ انتهاء'}
                  </div>
                  <div className="flex items-center gap-2">
                    <a href={doc.attachment_url} target="_blank" rel="noreferrer" className="p-1.5 text-muted-foreground hover:text-[#3ECFCF] hover:bg-[#3ECFCF]/10 rounded-md transition-colors" title="تنزيل">
                      <Download size={16} />
                    </a>
                    <button onClick={() => handleDelete(doc.document_id)} className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-md transition-colors" title="حذف">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Upload Modal */}
      {showUpload && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-6 w-full max-w-md shadow-xl border border-border">
            <h3 className="text-xl font-bold text-foreground mb-6">رفع مستند جديد</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">اسم المستند <span className="text-destructive">*</span></label>
                <input 
                  value={docName} 
                  onChange={e => setDocName(e.target.value)} 
                  className="w-full px-4 py-3 rounded-xl border border-border bg-muted/20 focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 focus:bg-white transition-all text-right"
                  placeholder="مثال: فاتورة حديد تسليح"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">نوع المستند <span className="text-destructive">*</span></label>
                <select 
                  value={docType} 
                  onChange={e => setDocType(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-border bg-muted/20 focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 focus:bg-white transition-all text-right"
                >
                  {DocumentTypes.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">تاريخ الانتهاء (اختياري)</label>
                <input 
                  type="date"
                  value={expiryDate} 
                  onChange={e => setExpiryDate(e.target.value)} 
                  className="w-full px-4 py-3 rounded-xl border border-border bg-muted/20 focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 focus:bg-white transition-all text-right"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">الملف (PDF, JPG, PNG) <span className="text-destructive">*</span></label>
                <input 
                  type="file"
                  onChange={e => setFile(e.target.files?.[0] || null)} 
                  className="w-full px-4 py-2.5 rounded-xl border border-dashed border-border bg-muted/20 focus:outline-none text-right text-sm"
                  accept=".pdf,.jpg,.jpeg,.png"
                />
                <p className="text-xs text-muted-foreground mt-1.5">الحد الأقصى 10 ميجابايت</p>
              </div>
            </div>
            
            <div className="flex gap-3 mt-8">
              <button 
                onClick={() => setShowUpload(false)} 
                className="flex-1 py-3 rounded-xl font-medium text-muted-foreground hover:bg-muted transition-colors"
                disabled={uploading}
              >
                إلغاء
              </button>
              <button
                onClick={handleUpload}
                disabled={uploading}
                className="flex-[2] py-3 rounded-xl font-semibold text-white transition-all hover:opacity-90 disabled:opacity-60 flex items-center justify-center gap-2"
                style={{ backgroundColor: '#1A1A1A' }}
              >
                {uploading ? (
                  <><Loader2 size={18} className="animate-spin" /> <span>جاري الرفع...</span></>
                ) : (
                  <><UploadCloud size={18} /> <span>رفع وحفظ</span></>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DocumentsPage;