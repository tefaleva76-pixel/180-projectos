import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Search as SearchIcon, Loader2, ArrowLeft } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import type { FinancialEvent } from '@/types';

const SearchPage: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [results, setResults] = useState<FinancialEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<'all' | 'Pending' | 'Approved'>('all');

  useEffect(() => {
    const q = searchParams.get('q') || '';
    if (q !== query) {
      setQuery(q);
    }
  }, [searchParams]);

  const handleQueryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setQuery(val);
    setSearchParams(val ? { q: val } : {}, { replace: true });
  };

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    const timer = setTimeout(() => {
      handleSearch();
    }, 500);
    return () => clearTimeout(timer);
  }, [query, filter]);

  const handleSearch = async () => {
    if (!profile || !query.trim()) return;
    setLoading(true);
    
    // In a real implementation we would search multiple tables or use a full-text search index
    // For this prototype, we'll do a simple ilike on descriptions within the user's company projects
    
    const { data: projects } = await supabase.from('projects').select('project_id').eq('company_id', profile.company_id);
    const projectIds = projects?.map(p => p.project_id) || [];
    
    if (projectIds.length > 0) {
      let queryBuilder = supabase
        .from('financial_events')
        .select('*, project:projects(project_name), phase:phases(phase_name), category:categories(category_name), profile:profiles(name), supplier:suppliers(supplier_name)')
        .in('project_id', projectIds)
        .order('created_at', { ascending: false })
        .limit(500);
        
      if (filter !== 'all') {
        queryBuilder = queryBuilder.eq('status', filter);
      }
      
      const { data } = await queryBuilder;
      if (data) {
        const lowerQ = query.toLowerCase();
        const filtered = data.filter(e => {
          return (
            e.description?.toLowerCase().includes(lowerQ) ||
            e.notes?.toLowerCase().includes(lowerQ) ||
            (e as any).project?.project_name?.toLowerCase().includes(lowerQ) ||
            e.category?.category_name?.toLowerCase().includes(lowerQ) ||
            e.profile?.name?.toLowerCase().includes(lowerQ) ||
            (e as any).supplier?.supplier_name?.toLowerCase().includes(lowerQ) ||
            e.amount?.toString().includes(lowerQ) ||
            e.event_type?.toLowerCase().includes(lowerQ)
          );
        });
        setResults(filtered.slice(0, 50) as FinancialEvent[]);
      } else {
        setResults([]);
      }
    } else {
      setResults([]);
    }
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-foreground mb-6">البحث العام</h1>
      
      <div className="bg-white rounded-2xl border border-border p-4 shadow-sm mb-6 sticky top-4 z-10">
        <div className="relative mb-4">
          <input
            type="text"
            value={query}
            onChange={handleQueryChange}
            placeholder="ابحث في الحركات المالية (الوصف، الملاحظات)..."
            className="w-full pl-4 pr-12 py-3 rounded-xl border border-border bg-muted/30 focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 focus:bg-white transition-all text-right"
            autoFocus
          />
          <SearchIcon className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={20} />
          {loading && (
            <div className="absolute left-4 top-1/2 -translate-y-1/2">
              <Loader2 className="animate-spin text-[#3ECFCF]" size={20} />
            </div>
          )}
        </div>
        
        <div className="flex gap-2 overflow-x-auto pb-1">
          {[
            { id: 'all', label: 'الكل' },
            { id: 'Pending', label: 'معلق' },
            { id: 'Approved', label: 'معتمد' }
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id as any)}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                filter === f.id
                  ? 'bg-[#1A1A1A] text-white'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {query.trim() && !loading && results.length === 0 && (
          <div className="text-center py-12 bg-white rounded-2xl border border-border">
            <SearchIcon className="mx-auto h-12 w-12 text-muted-foreground/30 mb-3" />
            <div className="text-lg font-medium text-foreground">لا توجد نتائج</div>
            <p className="text-sm text-muted-foreground mt-1">حاول استخدام كلمات بحث مختلفة</p>
          </div>
        )}
        
        {results.map(event => (
          <div key={event.event_id} className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 bg-white rounded-xl border border-border shadow-sm hover:shadow-md transition-shadow group cursor-pointer" onClick={() => navigate(`/dashboard/${event.project_id}`)}>
            <div className="flex items-center gap-4 flex-1 min-w-0">
              <div className={`w-3 h-3 rounded-full shrink-0 ${
                event.status === 'Approved' ? 'bg-[#10B981]' : event.status === 'Pending' ? 'bg-[#F59E0B]' : 'bg-[#EF4444]'
              }`} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-1">
                  <span className="text-base font-bold text-foreground">{event.event_type}</span>
                  <span className="text-base font-bold text-[#3ECFCF]">{Number(event.amount).toLocaleString()} EGP</span>
                </div>
                <div className="text-sm text-muted-foreground truncate mb-1">
                  {event.description || 'بدون وصف'}
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="bg-muted px-2 py-0.5 rounded">{event.phase?.phase_name}</span>
                  <span className="bg-muted px-2 py-0.5 rounded">{event.category?.category_name}</span>
                  <span>{new Date(event.created_at).toLocaleDateString('ar-EG')}</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 mt-3 sm:mt-0 pt-3 sm:pt-0 border-t border-border sm:border-0">
              <span className={`text-xs font-medium px-2.5 py-1 rounded-md ${
                event.status === 'Approved' ? 'bg-[#10B981]/10 text-[#10B981]' :
                event.status === 'Pending' ? 'bg-[#F59E0B]/10 text-[#F59E0B]' :
                'bg-[#EF4444]/10 text-[#EF4444]'
              }`}>
                {event.status === 'Approved' ? 'معتمد' : event.status === 'Pending' ? 'معلق' : 'مرفوض'}
              </span>
              <ArrowLeft size={16} className="text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SearchPage;