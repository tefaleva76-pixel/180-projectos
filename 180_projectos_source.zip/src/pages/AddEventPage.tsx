import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import type { EventType, Phase, Category, Supplier, Wallet } from '@/types';
import { toast } from 'sonner';
import { Loader2, ArrowLeft, Receipt, Truck, Wallet as WalletIcon, CreditCard, Users, RotateCcw, Plus } from 'lucide-react';

const eventTypes: { type: EventType; label: string; icon: React.ReactNode }[] = [
  { type: 'مصروف', label: 'مصروف', icon: <Receipt size={22} /> },
  { type: 'شراء أصل', label: 'شراء أصل', icon: <Truck size={22} /> },
  { type: 'شحن عهدة موقع', label: 'شحن عهدة', icon: <WalletIcon size={22} /> },
  { type: 'صرف من العهدة', label: 'صرف من العهدة', icon: <CreditCard size={22} /> },
  { type: 'دفعة مورد', label: 'دفعة مورد', icon: <Users size={22} /> },
  { type: 'راتب / أجر', label: 'راتب / أجر', icon: <Users size={22} /> },
  { type: 'مرتجع', label: 'مرتجع', icon: <RotateCcw size={22} /> },
  { type: 'مخصص', label: 'مخصص', icon: <Plus size={22} /> },
];

const paymentMethods = ['كاش / نقدي', 'تحويل بنكي', 'من العهدة النقدية', 'شيك', 'بطاقة ائتمان'];

const AddEventPage: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const { profile } = useAuth();
  const navigate = useNavigate();

  const [step, setStep] = useState(1);
  const [selectedType, setSelectedType] = useState<EventType | null>(null);
  const [loading, setLoading] = useState(false);
  const [phases, setPhases] = useState<Phase[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [wallets, setWallets] = useState<Wallet[]>([]);
  const [myWallet, setMyWallet] = useState<Wallet | null>(null);

  // Form fields
  const [amount, setAmount] = useState('');
  const [phaseId, setPhaseId] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [description, setDescription] = useState('');
  const [supplierId, setSupplierId] = useState('');
  const [walletId, setWalletId] = useState('');

  // Category quick add
  const [showNewCategory, setShowNewCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [savingCategory, setSavingCategory] = useState(false);
  const [generatingCategories, setGeneratingCategories] = useState(false);
  const [generatingPhases, setGeneratingPhases] = useState(false);

  // Dynamic fields
  const [machineName, setMachineName] = useState('');
  const [manufacturer, setManufacturer] = useState('');
  const [serialNumber, setSerialNumber] = useState('');
  const [warrantyDate, setWarrantyDate] = useState('');
  const [shippingCost, setShippingCost] = useState('');
  const [customsCost, setCustomsCost] = useState('');
  const [installCost, setInstallCost] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [employeeName, setEmployeeName] = useState('');
  const [dailyRate, setDailyRate] = useState('');
  const [daysCount, setDaysCount] = useState('');

  useEffect(() => {
    if (!projectId || !profile) return;
    fetchData();
  }, [projectId, profile]);

  const fetchData = async () => {
    const [phasesRes, catsRes, supRes, walletsRes] = await Promise.all([
      supabase.from('phases').select('*').eq('project_id', projectId).order('phase_order'),
      supabase.from('categories').select('*').eq('project_id', projectId),
      supabase.from('suppliers').select('*').eq('company_id', profile!.company_id),
      supabase.from('wallets').select('*, profile:profiles(name)').eq('company_id', profile!.company_id),
    ]);
    setPhases(phasesRes.data || []);
    setCategories(catsRes.data || []);
    setSuppliers(supRes.data || []);
    const walletList = (walletsRes.data || []) as Wallet[];
    setWallets(walletList);
    const own = walletList.find(w => w.user_id === profile?.user_id);
    setMyWallet(own || null);
  };

  const handleSave = async () => {
    if (!profile || !projectId || !selectedType) return;

    // Validation
    if (!amount || Number(amount) <= 0) { toast.error('يرجى إدخال مبلغ صحيح'); return; }
    if (!phaseId) { toast.error('يرجى اختيار المرحلة'); return; }
    if (!categoryId) { toast.error('يرجى اختيار الفئة'); return; }
    if (!paymentMethod) { toast.error('يرجى اختيار طريقة الدفع'); return; }

    // Wallet check for صرف من العهدة
    if (selectedType === 'صرف من العهدة' && myWallet) {
      if (Number(amount) > myWallet.current_balance) {
        toast.error(`الرصيد غير كافٍ. الرصيد الحالي: ${myWallet.current_balance.toLocaleString()} EGP`);
        return;
      }
      setWalletId(myWallet.wallet_id);
    }

    setLoading(true);

    const status = profile.role === 'Site_Engineer' ? 'Pending' : 'Approved';

    const { data: eventData, error: eventError } = await supabase
      .from('financial_events')
      .insert({
        project_id: projectId,
        phase_id: phaseId,
        category_id: categoryId,
        supplier_id: supplierId || null,
        wallet_id: (selectedType === 'صرف من العهدة' || selectedType === 'شحن عهدة موقع') ? walletId || null : null,
        user_id: profile.user_id,
        event_type: selectedType,
        amount: Number(amount),
        payment_method: paymentMethod as any,
        description: description.trim() || null,
        status,
      })
      .select()
      .single();

    if (eventError || !eventData) {
      toast.error('فشل في حفظ الحدث المالي');
      setLoading(false);
      return;
    }

    // Save transaction_meta for extra fields
    const metaEntries: { meta_key: string; meta_value: string; event_id: string }[] = [];
    if (machineName) metaEntries.push({ event_id: eventData.event_id, meta_key: 'machine_name', meta_value: machineName });
    if (manufacturer) metaEntries.push({ event_id: eventData.event_id, meta_key: 'manufacturer', meta_value: manufacturer });
    if (serialNumber) metaEntries.push({ event_id: eventData.event_id, meta_key: 'serial_number', meta_value: serialNumber });
    if (warrantyDate) metaEntries.push({ event_id: eventData.event_id, meta_key: 'warranty_date', meta_value: warrantyDate });
    if (shippingCost) metaEntries.push({ event_id: eventData.event_id, meta_key: 'shipping_cost', meta_value: shippingCost });
    if (customsCost) metaEntries.push({ event_id: eventData.event_id, meta_key: 'customs_cost', meta_value: customsCost });
    if (installCost) metaEntries.push({ event_id: eventData.event_id, meta_key: 'install_cost', meta_value: installCost });
    if (invoiceNumber) metaEntries.push({ event_id: eventData.event_id, meta_key: 'invoice_number', meta_value: invoiceNumber });
    if (employeeName) metaEntries.push({ event_id: eventData.event_id, meta_key: 'employee_name', meta_value: employeeName });
    if (dailyRate) metaEntries.push({ event_id: eventData.event_id, meta_key: 'daily_rate', meta_value: dailyRate });
    if (daysCount) metaEntries.push({ event_id: eventData.event_id, meta_key: 'days_count', meta_value: daysCount });

    if (metaEntries.length > 0) {
      await supabase.from('transaction_meta').insert(metaEntries);
    }

    toast.success('تم حفظ الحدث المالي بنجاح');
    setLoading(false);
    navigate(`/dashboard/${projectId}`);
  };

  const handleCreateCategory = async () => {
    if (!newCategoryName.trim() || !projectId) return;
    setSavingCategory(true);
    const { data, error } = await supabase.from('categories').insert({
      project_id: projectId,
      category_name: newCategoryName.trim(),
    }).select().single();
    
    if (error || !data) {
      toast.error('فشل في إضافة الفئة');
    } else {
      setCategories([...categories, data as Category]);
      setCategoryId(data.category_id);
      setShowNewCategory(false);
      setNewCategoryName('');
      toast.success('تمت إضافة الفئة بنجاح');
    }
    setSavingCategory(false);
  };

  const generateDefaultPhases = async () => {
    if (!projectId) return;
    setGeneratingPhases(true);
    const defaultPhases = [
      'مرحلة التأسيس والحفر',
      'مرحلة العظم والهيكل الخرساني',
      'مرحلة المباني والتقفيل',
      'مرحلة التأسيسات (سباكة وكهرباء)',
      'مرحلة التشطيبات والديكور',
      'مرحلة التسليم النهائي'
    ];
    
    const phaseInserts = defaultPhases.map((name, index) => ({
      project_id: projectId,
      phase_name: name,
      phase_order: index + 1
    }));
    
    const { data, error } = await supabase.from('phases').insert(phaseInserts).select();
    
    if (error || !data) {
      toast.error('فشل في توليد المراحل الأساسية');
    } else {
      setPhases([...phases, ...data]);
      toast.success('تم توليد المراحل بنجاح');
    }
    setGeneratingPhases(false);
  };

  const generateDefaultCategories = async () => {
    if (!projectId) return;
    setGeneratingCategories(true);
    const defaultCategories = [
      '🧱 مواد بناء وخامات (حديد، أسمنت، زلط، رمل، طوب)',
      '🚚 نقل ومشحونات ولوجستيات',
      '👷 أجور عمالة ومقاولين باطن',
      '📋 تراخيص ورسوم حكومية وأوراق رسمية',
      '🛠️ أدوات ومعدات وصيانة',
      '🔒 أمن وحراسة وسلامة مهنية'
    ];
    
    const categoryInserts = defaultCategories.map(name => ({
      project_id: projectId,
      category_name: name
    }));
    
    const { data, error } = await supabase.from('categories').insert(categoryInserts).select();
    
    if (error || !data) {
      toast.error('فشل في توليد الفئات الأساسية');
    } else {
      setCategories([...categories, ...(data as Category[])]);
      toast.success('تم توليد الفئات الأساسية بنجاح');
    }
    setGeneratingCategories(false);
  };

  const renderDynamicFields = () => {
    if (!selectedType) return null;

    const baseFields = (
      <>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">المبلغ <span className="text-destructive">*</span></label>
          <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">المرحلة <span className="text-destructive">*</span></label>
          {phases.length === 0 ? (
            <button
              type="button"
              onClick={generateDefaultPhases}
              disabled={generatingPhases}
              className="w-full px-4 py-3 rounded-xl border border-dashed border-[#3ECFCF]/50 bg-[#3ECFCF]/5 text-[#3ECFCF] hover:bg-[#3ECFCF]/10 transition-all flex items-center justify-center gap-2 text-sm font-medium disabled:opacity-50"
            >
              {generatingPhases ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
              اضغط هنا لتوليد المراحل الأساسية للمشروع فوراً
            </button>
          ) : (
            <select value={phaseId} onChange={e => setPhaseId(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right">
              <option value="">اختر المرحلة</option>
              {phases.map(p => <option key={p.phase_id} value={p.phase_id}>{p.phase_name}</option>)}
            </select>
          )}
        </div>
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="block text-sm font-medium text-foreground">الفئة <span className="text-destructive">*</span></label>
            <button 
              type="button"
              onClick={() => setShowNewCategory(!showNewCategory)} 
              className="text-xs text-[#3ECFCF] font-medium hover:underline flex items-center gap-1"
            >
              <Plus size={14} /> فئة جديدة
            </button>
          </div>
          {showNewCategory ? (
            <div className="flex items-center gap-2 bg-muted/30 p-2 rounded-xl border border-border mb-2">
              <input 
                value={newCategoryName}
                onChange={e => setNewCategoryName(e.target.value)}
                placeholder="اسم الفئة الجديدة..."
                className="flex-1 px-3 py-2 rounded-lg border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right text-sm"
              />
              <button 
                type="button"
                onClick={handleCreateCategory}
                disabled={savingCategory || !newCategoryName.trim()}
                className="px-3 py-2 bg-[#1A1A1A] text-white rounded-lg text-sm font-medium disabled:opacity-50"
              >
                {savingCategory ? <Loader2 size={16} className="animate-spin" /> : 'حفظ'}
              </button>
            </div>
          ) : null}
          {categories.length === 0 ? (
            <button
              type="button"
              onClick={generateDefaultCategories}
              disabled={generatingCategories}
              className="w-full px-4 py-3 rounded-xl border border-dashed border-[#3ECFCF]/50 bg-[#3ECFCF]/5 text-[#3ECFCF] hover:bg-[#3ECFCF]/10 transition-all flex items-center justify-center gap-2 text-sm font-medium disabled:opacity-50"
            >
              {generatingCategories ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
              اضغط هنا لتوليد الفئات الأساسية للمشروع فوراً
            </button>
          ) : (
            <select value={categoryId} onChange={e => setCategoryId(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right">
              <option value="">اختر الفئة</option>
              {categories.map(c => <option key={c.category_id} value={c.category_id}>{c.category_name}</option>)}
            </select>
          )}
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">طريقة الدفع <span className="text-destructive">*</span></label>
          <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right">
            <option value="">اختر طريقة الدفع</option>
            {paymentMethods.map(m => <option key={m} value={m}>{m}</option>)}
          </select>
        </div>
      </>
    );

    switch (selectedType) {
      case 'مصروف':
        return (
          <div className="space-y-4">
            {baseFields}
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">الوصف</label>
              <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right min-h-[80px]" placeholder="وصف المصروف..." />
            </div>
          </div>
        );
      case 'شراء أصل':
        return (
          <div className="space-y-4">
            {baseFields}
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">اسم الماكينة</label>
              <input value={machineName} onChange={e => setMachineName(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">الشركة المصنعة</label>
              <input value={manufacturer} onChange={e => setManufacturer(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">الرقم التسلسلي</label>
              <input value={serialNumber} onChange={e => setSerialNumber(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">تاريخ الضمان</label>
              <input type="date" value={warrantyDate} onChange={e => setWarrantyDate(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">تكلفة الشحن</label>
                <input type="number" value={shippingCost} onChange={e => setShippingCost(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">الجمارك</label>
                <input type="number" value={customsCost} onChange={e => setCustomsCost(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">التركيب</label>
                <input type="number" value={installCost} onChange={e => setInstallCost(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
              </div>
            </div>
          </div>
        );
      case 'شحن عهدة موقع':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">اختر المهندس <span className="text-destructive">*</span></label>
              <select value={walletId} onChange={e => setWalletId(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right">
                <option value="">اختر المهندس</option>
                {wallets.map(w => (
                  <option key={w.wallet_id} value={w.wallet_id}>{w.profile?.name || w.user_id}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">المبلغ <span className="text-destructive">*</span></label>
              <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">ملاحظات</label>
              <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right min-h-[80px]" />
            </div>
          </div>
        );
      case 'صرف من العهدة':
        return (
          <div className="space-y-4">
            <div className="bg-[#3ECFCF]/10 rounded-xl p-4 flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">الرصيد الحالي</span>
              <span className="text-lg font-bold text-[#3ECFCF]">{myWallet?.current_balance.toLocaleString() || 0} EGP</span>
            </div>
            {baseFields}
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">الوصف</label>
              <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right min-h-[80px]" />
            </div>
          </div>
        );
      case 'دفعة مورد':
        return (
          <div className="space-y-4">
            {baseFields}
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">المورد</label>
              <select value={supplierId} onChange={e => setSupplierId(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right">
                <option value="">اختر المورد</option>
                {suppliers.map(s => <option key={s.supplier_id} value={s.supplier_id}>{s.supplier_name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">رقم الفاتورة</label>
              <input value={invoiceNumber} onChange={e => setInvoiceNumber(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
            </div>
          </div>
        );
      case 'راتب / أجر':
        return (
          <div className="space-y-4">
            {baseFields}
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">اسم الموظف</label>
              <input value={employeeName} onChange={e => setEmployeeName(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">الأجر اليومي</label>
                <input type="number" value={dailyRate} onChange={e => setDailyRate(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">عدد الأيام</label>
                <input type="number" value={daysCount} onChange={e => setDaysCount(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
              </div>
            </div>
          </div>
        );
      default:
        return (
          <div className="space-y-4">
            {baseFields}
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">الوصف</label>
              <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right min-h-[80px]" />
            </div>
          </div>
        );
    }
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(`/dashboard/${projectId}`)} className="text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-2xl font-bold text-foreground">إضافة حدث مالي</h1>
      </div>

      {step === 1 && (
        <div className="space-y-5">
          <h2 className="text-lg font-semibold text-foreground">اختر نوع الحدث</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {eventTypes.map(opt => (
              <button
                key={opt.type}
                onClick={() => { setSelectedType(opt.type); setStep(2); }}
                className="flex flex-col items-center gap-3 p-5 rounded-2xl border-2 border-border bg-white hover:border-[#3ECFCF] hover:bg-[#3ECFCF]/5 transition-all"
              >
                <span className="text-[#3ECFCF]">{opt.icon}</span>
                <span className="font-semibold text-foreground text-sm">{opt.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {step === 2 && selectedType && (
        <div className="bg-white rounded-2xl border border-border p-6 shadow-sm space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-foreground">{selectedType}</h2>
            <button onClick={() => setStep(1)} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              تغيير النوع
            </button>
          </div>
          {renderDynamicFields()}
          <div className="flex justify-start pt-4">
            <button
              onClick={handleSave}
              disabled={loading}
              className="px-6 py-3 rounded-xl font-semibold text-white transition-all hover:opacity-90 disabled:opacity-60 flex items-center gap-2"
              style={{ backgroundColor: '#1A1A1A' }}
            >
              {loading && <Loader2 size={18} className="animate-spin" />}
              <span>حفظ الحدث</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AddEventPage;
