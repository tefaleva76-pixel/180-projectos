import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      toast.error('يرجى إدخال البريد الإلكتروني وكلمة المرور');
      return;
    }
    setLoading(true);
    const result = await login(email, password);
    setLoading(false);
    if (result.error) {
      toast.error('البريد الإلكتروني أو كلمة المرور غير صحيحة');
    } else {
      toast.success('تم تسجيل الدخول بنجاح');
      navigate('/portfolio');
    }
  };

  const handleDemoLogin = async (role: 'owner' | 'accountant' | 'engineer') => {
    const credentials = {
      owner: { email: 'owner@180.com', password: 'password123', name: 'المالك' },
      accountant: { email: 'accountant@180.com', password: 'password123', name: 'المحاسب' },
      engineer: { email: 'engineer@180.com', password: 'password123', name: 'مهندس الموقع' }
    };
    
    setLoading(true);
    const result = await login(credentials[role].email, credentials[role].password);
    setLoading(false);
    
    if (result.error) {
      toast.error('حدث خطأ أثناء تسجيل الدخول التجريبي: ' + result.error);
    } else {
      toast.success('تم تسجيل الدخول بنجاح');
      navigate('/portfolio');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-white px-4 py-12">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-10">
          <img src="/ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico" alt="180° ProjectOS Logo" className="h-32 object-contain mx-auto mb-4" />
          <p className="text-muted-foreground text-sm">إدارة كل مشروع. تتبع كل جنيه.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 mb-8">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">البريد الإلكتروني</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 transition-all text-right"
              placeholder="example@company.com"
              dir="ltr"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">كلمة المرور</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 transition-all text-right"
              placeholder="••••••••"
              dir="ltr"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl font-semibold text-white transition-all hover:opacity-90 disabled:opacity-60 flex items-center justify-center gap-2"
            style={{ backgroundColor: '#1A1A1A' }}
          >
            {loading ? <Loader2 size={18} className="animate-spin" /> : null}
            <span>تسجيل الدخول</span>
          </button>
        </form>

        <div className="relative mb-8">
          <div className="absolute inset-0 flex items-center">
            <span className="w-full border-t border-border" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-white px-2 text-muted-foreground">تسجيل دخول تجريبي / Demo Login</span>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3">
          <button
            type="button"
            onClick={() => handleDemoLogin('owner')}
            disabled={loading}
            className="w-full px-4 py-3 rounded-xl border-2 border-[#3ECFCF]/30 bg-[#3ECFCF]/5 hover:bg-[#3ECFCF]/10 text-foreground font-semibold transition-colors flex items-center justify-between group disabled:opacity-60"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-[#3ECFCF]/20 flex items-center justify-center text-[#1A1A1A]">
                👨‍💼
              </div>
              <div className="text-right">
                <div className="text-sm">المالك (Owner)</div>
                <div className="text-xs text-muted-foreground font-normal">وصول كامل لجميع المشاريع</div>
              </div>
            </div>
            <span className="text-xl opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all">←</span>
          </button>
          
          <button
            type="button"
            onClick={() => handleDemoLogin('accountant')}
            disabled={loading}
            className="w-full px-4 py-3 rounded-xl border-2 border-[#10B981]/30 bg-[#10B981]/5 hover:bg-[#10B981]/10 text-foreground font-semibold transition-colors flex items-center justify-between group disabled:opacity-60"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-[#10B981]/20 flex items-center justify-center text-[#1A1A1A]">
                📊
              </div>
              <div className="text-right">
                <div className="text-sm">المحاسب (Accountant)</div>
                <div className="text-xs text-muted-foreground font-normal">إدارة الميزانية والمصروفات</div>
              </div>
            </div>
            <span className="text-xl opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all">←</span>
          </button>

          <button
            type="button"
            onClick={() => handleDemoLogin('engineer')}
            disabled={loading}
            className="w-full px-4 py-3 rounded-xl border-2 border-[#F59E0B]/30 bg-[#F59E0B]/5 hover:bg-[#F59E0B]/10 text-foreground font-semibold transition-colors flex items-center justify-between group disabled:opacity-60"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-[#F59E0B]/20 flex items-center justify-center text-[#1A1A1A]">
                👷
              </div>
              <div className="text-right">
                <div className="text-sm">مهندس الموقع (Site Engineer)</div>
                <div className="text-xs text-muted-foreground font-normal">إضافة فواتير وعهد يومية</div>
              </div>
            </div>
            <span className="text-xl opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all">←</span>
          </button>
        </div>

        <div className="mt-10 text-center">
          <p className="text-xs text-muted-foreground">مدعوم من 180°</p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
