import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Loader2, Home, Factory, Tractor, Hotel, ShoppingBag, FileText, X, Plus, ArrowLeft, ArrowRight } from 'lucide-react';
import type { ProjectType, Phase } from '@/types';

const typeOptions: { type: ProjectType; label: string; icon: React.ReactNode }[] = [
  { type: 'Residential', label: 'سكني', icon: <Home size={24} /> },
  { type: 'Industrial', label: 'صناعي', icon: <Factory size={24} /> },
  { type: 'Farm', label: 'مزرعة', icon: <Tractor size={24} /> },
  { type: 'Hotel', label: 'فندق', icon: <Hotel size={24} /> },
  { type: 'Mall', label: 'مول', icon: <ShoppingBag size={24} /> },
  { type: 'Custom', label: 'مخصص', icon: <FileText size={24} /> },
];

const NewProjectPage: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [templates, setTemplates] = useState<Record<string, { name: string; order: number }[]>>({});

  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [budget, setBudget] = useState('');
  const [selectedType, setSelectedType] = useState<ProjectType | null>(null);
  const [phases, setPhases] = useState<{ name: string; order: number }[]>([]);

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    const { data } = await supabase.from('project_templates').select('*');
    const map: Record<string, { name: string; order: number }[]> = {};
    for (const t of data || []) {
      map[t.project_type] = t.default_phases as { name: string; order: number }[];
    }
    setTemplates(map);
  };

  const handleTypeSelect = (type: ProjectType) => {
    setSelectedType(type);
    const tpl = templates[type] || [];
    setPhases(tpl.map((p, i) => ({ ...p, order: i + 1 })));
  };

  const addPhase = () => {
    setPhases([...phases, { name: '', order: phases.length + 1 }]);
  };

  const removePhase = (idx: number) => {
    const updated = phases.filter((_, i) => i !== idx);
    setPhases(updated.map((p, i) => ({ ...p, order: i + 1 })));
  };

  const updatePhaseName = (idx: number, name: string) => {
    const updated = [...phases];
    updated[idx].name = name;
    setPhases(updated);
  };

  const handleSave = async () => {
    if (!profile) return;
    if (!name.trim()) { toast.error('يرجى إدخال اسم المشروع'); return; }
    if (!budget.trim()) { toast.error('يرجى إدخال الميزانية'); return; }
    if (!selectedType) { toast.error('يرجى اختيار نوع المشروع'); return; }
    const validPhases = phases.filter(p => p.name.trim());
    if (validPhases.length === 0) { toast.error('يرجى إضافة مرحلة واحدة على الأقل'); return; }

    setLoading(true);
    const { data: projectData, error: projectError } = await supabase
      .from('projects')
      .insert({
        company_id: profile.company_id,
        project_name: name.trim(),
        location: location.trim() || null,
        budget: Number(budget),
        project_type: selectedType,
        status: 'Planning',
      })
      .select()
      .single();

    if (projectError || !projectData) {
      toast.error('فشل في إنشاء المشروع');
      setLoading(false);
      return;
    }

    const phaseInserts = validPhases.map(p => ({
      project_id: projectData.project_id,
      phase_name: p.name.trim(),
      phase_order: p.order,
      status: 'Not_Started' as const,
    }));

    const { error: phaseError } = await supabase.from('phases').insert(phaseInserts);
    if (phaseError) {
      toast.error('فشل في إضافة المراحل');
    }

    // Seed default categories
    const defaultCategories = [
      '🧱 مواد بناء وخامات (حديد، أسمنت، زلط، رمل، طوب)',
      '🚚 نقل ومشحونات ولوجستيات',
      '👷 أجور عمالة ومقاولين باطن',
      '📋 تراخيص ورسوم حكومية وأوراق رسمية',
      '🛠️ أدوات ومعدات وصيانة',
      '🔒 أمن وحراسة وسلامة مهنية'
    ];
    
    const categoryInserts = defaultCategories.map(name => ({
      project_id: projectData.project_id,
      category_name: name
    }));
    
    await supabase.from('categories').insert(categoryInserts);

    if (!phaseError) {
      toast.success('تم إنشاء المشروع بنجاح');
      navigate('/portfolio');
    }
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate('/portfolio')} className="text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-2xl font-bold text-foreground">إنشاء مشروع جديد</h1>
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-2 mb-8">
        {[1, 2, 3].map(s => (
          <div key={s} className="contents">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${
              s === step ? 'bg-[#3ECFCF] text-white' : s < step ? 'bg-[#1A1A1A] text-white' : 'bg-muted text-muted-foreground'
            }`}>
              {s}
            </div>
            {s < 3 && <div className={`flex-1 h-1 rounded-full ${s < step ? 'bg-[#1A1A1A]' : 'bg-muted'}`} />}
          </div>
        ))}
      </div>

      {step === 1 && (
        <div className="space-y-5 bg-white rounded-2xl border border-border p-6 shadow-sm">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">اسم المشروع <span className="text-destructive">*</span></label>
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 transition-all text-right"
              placeholder="مثال: فيلا الزهراء"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">الموقع</label>
            <input
              value={location}
              onChange={e => setLocation(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 transition-all text-right"
              placeholder="مثال: القاهرة الجديدة"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">الميزانية الإجمالية <span className="text-destructive">*</span></label>
            <input
              type="number"
              value={budget}
              onChange={e => setBudget(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 transition-all text-right"
              placeholder="مثال: 500000"
            />
          </div>
          <div className="flex justify-start">
            <button
              onClick={() => setStep(2)}
              className="px-6 py-3 rounded-xl font-semibold text-white transition-all hover:opacity-90"
              style={{ backgroundColor: '#1A1A1A' }}
            >
              التالي
            </button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-5">
          <h2 className="text-lg font-semibold text-foreground">اختر نوع المشروع</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {typeOptions.map(opt => (
              <button
                key={opt.type}
                onClick={() => handleTypeSelect(opt.type)}
                className={`flex flex-col items-center gap-3 p-6 rounded-2xl border-2 transition-all ${
                  selectedType === opt.type
                    ? 'border-[#3ECFCF] bg-[#3ECFCF]/5'
                    : 'border-border bg-white hover:border-[#3ECFCF]/40'
                }`}
              >
                <span className={selectedType === opt.type ? 'text-[#3ECFCF]' : 'text-muted-foreground'}>
                  {opt.icon}
                </span>
                <span className="font-semibold text-foreground">{opt.label}</span>
              </button>
            ))}
          </div>
          <div className="flex justify-between">
            <button onClick={() => setStep(1)} className="px-6 py-3 rounded-xl font-medium text-muted-foreground hover:bg-muted transition-colors">
              السابق
            </button>
            <button
              onClick={() => selectedType && setStep(3)}
              disabled={!selectedType}
              className="px-6 py-3 rounded-xl font-semibold text-white transition-all hover:opacity-90 disabled:opacity-40"
              style={{ backgroundColor: '#1A1A1A' }}
            >
              التالي
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-foreground">المراحل</h2>
            <button onClick={addPhase} className="flex items-center gap-1 text-sm text-[#3ECFCF] font-medium hover:underline">
              <Plus size={16} />
              إضافة مرحلة
            </button>
          </div>
          <div className="space-y-3">
            {phases.map((phase, idx) => (
              <div key={idx} className="flex items-center gap-3 bg-white rounded-xl border border-border p-3 shadow-sm">
                <span className="w-8 h-8 flex items-center justify-center rounded-lg bg-muted text-sm font-bold text-muted-foreground">
                  {phase.order}
                </span>
                <input
                  value={phase.name}
                  onChange={e => updatePhaseName(idx, e.target.value)}
                  className="flex-1 px-3 py-2 rounded-lg border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right"
                  placeholder="اسم المرحلة"
                />
                <button onClick={() => removePhase(idx)} className="text-muted-foreground hover:text-destructive transition-colors p-1">
                  <X size={18} />
                </button>
              </div>
            ))}
            {phases.length === 0 && (
              <div className="text-center py-8 text-muted-foreground border border-dashed border-border rounded-xl">
                لا توجد مراحل. اضغط "إضافة مرحلة" لبدء التعبئة.
              </div>
            )}
          </div>
          <div className="flex justify-between pt-4">
            <button onClick={() => setStep(2)} className="px-6 py-3 rounded-xl font-medium text-muted-foreground hover:bg-muted transition-colors">
              السابق
            </button>
            <button
              onClick={handleSave}
              disabled={loading}
              className="px-6 py-3 rounded-xl font-semibold text-white transition-all hover:opacity-90 disabled:opacity-60 flex items-center gap-2"
              style={{ backgroundColor: '#1A1A1A' }}
            >
              {loading && <Loader2 size={18} className="animate-spin" />}
              <span>حفظ المشروع</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default NewProjectPage;
