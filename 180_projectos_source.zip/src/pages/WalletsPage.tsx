import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import type { Wallet, FinancialEvent } from '@/types';
import { toast } from 'sonner';
import { Wallet as WalletIcon, Plus, Loader2, ArrowLeft } from 'lucide-react';

const WalletsPage: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [wallets, setWallets] = useState<Wallet[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedWallet, setSelectedWallet] = useState<Wallet | null>(null);
  const [history, setHistory] = useState<FinancialEvent[]>([]);
  const [showTopUp, setShowTopUp] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState('');
  const [topUpProjectId, setTopUpProjectId] = useState('');
  const [projects, setProjects] = useState<{ project_id: string; project_name: string }[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!profile) return;
    fetchWallets();
    fetchProjects();
  }, [profile]);

  const fetchWallets = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('wallets')
      .select('*, profile:profiles(name, email)')
      .eq('company_id', profile!.company_id);
    setWallets((data || []) as Wallet[]);
    setLoading(false);
  };

  const fetchProjects = async () => {
    const { data } = await supabase.from('projects').select('project_id, project_name').eq('company_id', profile!.company_id);
    setProjects(data || []);
  };

  const fetchHistory = async (wallet: Wallet) => {
    setSelectedWallet(wallet);
    const { data } = await supabase
      .from('financial_events')
      .select('*, phase:phases(phase_name)')
      .eq('wallet_id', wallet.wallet_id)
      .order('created_at', { ascending: false });
    setHistory((data || []) as FinancialEvent[]);
  };

  const handleTopUp = async () => {
    if (!profile || !selectedWallet || !topUpAmount || !topUpProjectId) return;
    setSaving(true);

    // Get first phase and category for the selected project
    const { data: phases } = await supabase.from('phases').select('phase_id').eq('project_id', topUpProjectId).limit(1);
    const { data: cats } = await supabase.from('categories').select('category_id').eq('project_id', topUpProjectId).limit(1);

    if (!phases?.length || !cats?.length) {
      toast.error('المشروع لا يحتوي على مراحل أو فئات');
      setSaving(false);
      return;
    }

    const { error } = await supabase.from('financial_events').insert({
      project_id: topUpProjectId,
      phase_id: phases[0].phase_id,
      category_id: cats[0].category_id,
      wallet_id: selectedWallet.wallet_id,
      user_id: profile.user_id,
      event_type: 'شحن عهدة موقع',
      amount: Number(topUpAmount),
      payment_method: 'كاش / نقدي',
      status: 'Approved',
    });

    if (error) {
      toast.error('فشل في شحن العهدة');
    } else {
      toast.success('تم شحن العهدة بنجاح');
      setShowTopUp(false);
      setTopUpAmount('');
      fetchWallets();
      if (selectedWallet) fetchHistory(selectedWallet);
    }
    setSaving(false);
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold text-foreground mb-6">إدارة العهد النقدية</h1>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-[#3ECFCF]" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {wallets.map(wallet => {
            const pct = wallet.total_received > 0 ? (wallet.current_balance / wallet.total_received) * 100 : 0;
            const lowBalance = wallet.total_received > 0 && pct < 10;
            return (
              <button
                key={wallet.wallet_id}
                onClick={() => fetchHistory(wallet)}
                className={`text-right bg-white rounded-2xl border p-5 shadow-sm transition-all hover:shadow-md ${
                  selectedWallet?.wallet_id === wallet.wallet_id ? 'border-[#3ECFCF]' : 'border-border'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#3ECFCF]/10 flex items-center justify-center text-[#3ECFCF]">
                      <WalletIcon size={20} />
                    </div>
                    <div>
                      <div className="font-bold text-foreground">{wallet.profile?.name || 'مهندس'}</div>
                      <div className="text-xs text-muted-foreground">{wallet.profile?.email}</div>
                    </div>
                  </div>
                  {lowBalance && (
                    <span className="text-xs font-medium px-2 py-1 rounded-md bg-[#F59E0B]/10 text-[#F59E0B]">رصيد منخفض</span>
                  )}
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">الرصيد الحالي</span>
                    <span className="text-lg font-bold text-foreground">{wallet.current_balance.toLocaleString()} EGP</span>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${pct}%`,
                        backgroundColor: lowBalance ? '#F59E0B' : '#3ECFCF',
                      }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>إجمالي المستلم: {wallet.total_received.toLocaleString()}</span>
                    <span>إجمالي المصروف: {wallet.total_spent.toLocaleString()}</span>
                  </div>
                </div>
                {profile?.role === 'Owner' && (
                  <button
                    onClick={e => { e.stopPropagation(); setSelectedWallet(wallet); setShowTopUp(true); }}
                    className="mt-4 w-full py-2 rounded-lg font-medium text-sm bg-[#1A1A1A] text-white hover:opacity-90 transition-opacity"
                  >
                    شحن عهدة
                  </button>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* History panel */}
      {selectedWallet && !showTopUp && (
        <div className="mt-6 bg-white rounded-2xl border border-border p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-foreground">سجل العهدة — {selectedWallet.profile?.name}</h3>
            <button onClick={() => setSelectedWallet(null)} className="text-muted-foreground hover:text-foreground">
              <ArrowLeft size={18} />
            </button>
          </div>
          {history.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">لا توجد حركات</div>
          ) : (
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {history.map(h => (
                <div key={h.event_id} className="flex items-center justify-between p-3 rounded-xl bg-muted/30">
                  <div>
                    <div className="font-medium text-sm text-foreground">{h.event_type}</div>
                    <div className="text-xs text-muted-foreground">{h.phase?.phase_name}</div>
                  </div>
                  <div className="text-left">
                    <div className={`font-bold text-sm ${h.event_type === 'شحن عهدة موقع' ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                      {h.event_type === 'شحن عهدة موقع' ? '+' : '-'}{Number(h.amount).toLocaleString()} EGP
                    </div>
                    <div className="text-xs text-muted-foreground">{new Date(h.created_at).toLocaleDateString('ar-EG')}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Top Up Modal */}
      {showTopUp && selectedWallet && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl">
            <h3 className="text-lg font-bold text-foreground mb-4">شحن عهدة — {selectedWallet.profile?.name}</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">المشروع</label>
                <select value={topUpProjectId} onChange={e => setTopUpProjectId(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right">
                  <option value="">اختر المشروع</option>
                  {projects.map(p => <option key={p.project_id} value={p.project_id}>{p.project_name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">المبلغ</label>
                <input type="number" value={topUpAmount} onChange={e => setTopUpAmount(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 text-right" />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowTopUp(false)} className="flex-1 py-2.5 rounded-xl font-medium text-muted-foreground hover:bg-muted transition-colors">
                إلغاء
              </button>
              <button
                onClick={handleTopUp}
                disabled={saving}
                className="flex-1 py-2.5 rounded-xl font-semibold text-white transition-all hover:opacity-90 disabled:opacity-60 flex items-center justify-center gap-2"
                style={{ backgroundColor: '#1A1A1A' }}
              >
                {saving && <Loader2 size={16} className="animate-spin" />}
                <span>شحن</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WalletsPage;
