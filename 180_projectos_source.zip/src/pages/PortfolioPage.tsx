import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import type { Project } from '@/types';
import { toast } from 'sonner';
import { Plus, Home, Factory, Tractor, Hotel, ShoppingBag, FileText, Loader2, Trash2 } from 'lucide-react';

const typeIcons: Record<string, React.ReactNode> = {
  Residential: <Home size={20} />,
  Industrial: <Factory size={20} />,
  Farm: <Tractor size={20} />,
  Hotel: <Hotel size={20} />,
  Mall: <ShoppingBag size={20} />,
  Custom: <FileText size={20} />,
};

const typeLabels: Record<string, string> = {
  Residential: 'سكني',
  Industrial: 'صناعي',
  Farm: 'مزرعة',
  Hotel: 'فندق',
  Mall: 'مول',
  Custom: 'مخصص',
};

const statusLabels: Record<string, string> = {
  Planning: 'قيد التخطيط',
  In_Progress: 'قيد التنفيذ',
  On_Hold: 'متوقف مؤقتاً',
  Completed: 'مكتمل',
};

const PortfolioPage: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');
  const [budgetMap, setBudgetMap] = useState<Record<string, { spent: number; planned: number }>>({});

  useEffect(() => {
    if (!profile) return;
    fetchProjects();
  }, [profile]);

  const fetchProjects = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .eq('company_id', profile!.company_id)
      .order('created_at', { ascending: false });
    if (error) {
      toast.error('فشل في تحميل المشاريع');
    } else {
      setProjects(data || []);
      // Fetch budget data for each project
      const projectIds = (data || []).map(p => p.project_id);
      if (projectIds.length > 0) {
        const { data: budgetData } = await supabase
          .from('budgets')
          .select('project_id, planned_amount, actual_amount')
          .in('project_id', projectIds);
        const map: Record<string, { spent: number; planned: number }> = {};
        for (const p of data || []) {
          map[p.project_id] = { spent: 0, planned: Number(p.budget) };
        }
        for (const b of budgetData || []) {
          if (map[b.project_id]) {
            map[b.project_id].spent += Number(b.actual_amount);
          }
        }
        setBudgetMap(map);
      }
    }
    setLoading(false);
  };

  const filteredProjects = filter === 'all'
    ? projects
    : projects.filter(p => {
        if (filter === 'in_progress') return p.status === 'In_Progress';
        if (filter === 'completed') return p.status === 'Completed';
        return true;
      });

  const handleDelete = async (e: React.MouseEvent, projectId: string) => {
    e.stopPropagation();
    if (window.confirm('هل أنت متأكد من حذف هذا المشروع؟ سيتم حذف جميع البيانات المرتبطة به نهائياً.')) {
      const { error } = await supabase.from('projects').delete().eq('project_id', projectId);
      if (error) {
        toast.error('حدث خطأ أثناء الحذف');
      } else {
        toast.success('تم حذف المشروع بنجاح');
        setProjects(projects.filter(p => p.project_id !== projectId));
      }
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-foreground">محفظة المشاريع</h1>
        <button
          onClick={() => navigate('/new-project')}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-white font-medium transition-all hover:opacity-90 shadow-sm"
          style={{ backgroundColor: '#1A1A1A' }}
        >
          <Plus size={18} />
          <span>مشروع جديد</span>
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-6">
        {[
          { key: 'all', label: 'الكل' },
          { key: 'in_progress', label: 'قيد التنفيذ' },
          { key: 'completed', label: 'مكتمل' },
        ].map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === f.key
                ? 'bg-[#1A1A1A] text-white'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 size={32} className="animate-spin text-[#3ECFCF]" />
        </div>
      ) : filteredProjects.length === 0 ? (
        <div className="text-center py-20 text-muted-foreground">
          لا توجد مشاريع
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredProjects.map(project => {
            const spent = budgetMap[project.project_id]?.spent || 0;
            const planned = budgetMap[project.project_id]?.planned || Number(project.budget) || 1;
            const pct = Math.min((spent / planned) * 100, 100);
            return (
              <button
                key={project.project_id}
                onClick={() => navigate(`/dashboard/${project.project_id}`)}
                className="text-right bg-white rounded-2xl border border-border p-5 shadow-sm hover:shadow-md transition-all hover:border-[#3ECFCF]/30 group"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-[#3ECFCF]">{typeIcons[project.project_type]}</span>
                    <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded-md">
                      {typeLabels[project.project_type]}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => handleDelete(e, project.project_id)}
                      className="p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-md transition-colors"
                      title="حذف المشروع"
                    >
                      <Trash2 size={16} />
                    </button>
                    <span className="text-xs font-medium px-2 py-1 rounded-md bg-[#3ECFCF]/10 text-[#1A1A1A]">
                      {statusLabels[project.status]}
                    </span>
                  </div>
                </div>
                <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-[#3ECFCF] transition-colors">
                  {project.project_name}
                </h3>
                {project.location && (
                  <p className="text-xs text-muted-foreground mb-3">{project.location}</p>
                )}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">المصروفات</span>
                    <span className="font-semibold">{spent.toLocaleString()} {project.currency}</span>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${pct}%`,
                        backgroundColor: pct > 90 ? '#EF4444' : pct > 70 ? '#F59E0B' : '#3ECFCF',
                      }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{pct.toFixed(1)}% من الميزانية</span>
                    <span>{Number(project.budget).toLocaleString()} {project.currency}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default PortfolioPage;
