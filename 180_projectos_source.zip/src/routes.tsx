import LoginPage from './pages/LoginPage';
import PortfolioPage from './pages/PortfolioPage';
import NewProjectPage from './pages/NewProjectPage';
import DashboardPage from './pages/DashboardPage';
import AddEventPage from './pages/AddEventPage';
import WalletsPage from './pages/WalletsPage';
import ManagementPage from './pages/ManagementPage';
import AppLayout from './components/layout/AppLayout';
import ReportsPage from './pages/ReportsPage';
import SearchPage from './pages/SearchPage';
import DocumentsPage from './pages/DocumentsPage';
import type { ReactNode } from 'react';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  /** Accessible without login. Routes without this flag require authentication. Has no effect when RouteGuard is not in use. */
  public?: boolean;
}

export const routes: RouteConfig[] = [
  {
    name: 'Login Page',
    path: '/login',
    element: <LoginPage />,
    public: true,
  },
  {
    name: 'Portfolio Page',
    path: '/portfolio',
    element: <AppLayout><PortfolioPage /></AppLayout>,
  },
  {
    name: 'New Project Page',
    path: '/new-project',
    element: <AppLayout><NewProjectPage /></AppLayout>,
  },
  {
    name: 'Dashboard Page',
    path: '/dashboard/:projectId',
    element: <AppLayout><DashboardPage /></AppLayout>,
  },
  {
    name: 'Add Event Page',
    path: '/add-event/:projectId',
    element: <AppLayout><AddEventPage /></AppLayout>,
  },
  {
    name: 'Wallets Page',
    path: '/wallets',
    element: <AppLayout><WalletsPage /></AppLayout>,
  },
  {
    name: 'Management Page',
    path: '/management',
    element: <AppLayout><ManagementPage /></AppLayout>,
  },
  {
    name: 'Reports Page',
    path: '/reports',
    element: <AppLayout><ReportsPage /></AppLayout>,
  },
  {
    name: 'Search Page',
    path: '/search',
    element: <AppLayout><SearchPage /></AppLayout>,
  },
  {
    name: 'Documents Page',
    path: '/documents',
    element: <AppLayout><DocumentsPage /></AppLayout>,
  }
];
