export type UserRole = 'Owner' | 'Accountant' | 'Site_Engineer';

export type ProjectType = 'Residential' | 'Industrial' | 'Farm' | 'Hotel' | 'Mall' | 'Custom';

export type ProjectStatus = 'Planning' | 'In_Progress' | 'On_Hold' | 'Completed';

export type PhaseStatus = 'Not_Started' | 'In_Progress' | 'On_Hold' | 'Completed';

export type EventType =
  | 'مصروف'
  | 'شراء أصل'
  | 'إيراد'
  | 'دفعة مورد'
  | 'راتب / أجر'
  | 'إيجار'
  | 'صيانة'
  | 'مرتجع'
  | 'سلفة'
  | 'شحن عهدة موقع'
  | 'صرف من العهدة'
  | 'مخصص';

export type PaymentMethod =
  | 'كاش / نقدي'
  | 'تحويل بنكي'
  | 'من العهدة النقدية'
  | 'شيك'
  | 'بطاقة ائتمان';

export type EventStatus = 'Pending' | 'Approved' | 'Rejected';

export interface Company {
  company_id: string;
  company_name: string;
  logo?: string;
  address?: string;
  phone?: string;
  created_at: string;
}

export interface Profile {
  user_id: string;
  company_id: string;
  name: string;
  email: string;
  role: UserRole;
  status: string;
  created_at: string;
}

export interface Project {
  project_id: string;
  company_id: string;
  project_name: string;
  project_type: ProjectType;
  location?: string;
  budget: number;
  currency: string;
  status: ProjectStatus;
  created_at: string;
}

export interface Phase {
  phase_id: string;
  project_id: string;
  phase_name: string;
  phase_order: number;
  status: PhaseStatus;
  created_at: string;
}

export interface Category {
  category_id: string;
  project_id: string;
  category_name: string;
  icon: string;
  color: string;
  created_at: string;
}

export interface Supplier {
  supplier_id: string;
  company_id: string;
  supplier_name: string;
  phone?: string;
  email?: string;
  tax_number?: string;
  notes?: string;
  created_at: string;
}

export interface Wallet {
  wallet_id: string;
  user_id: string;
  company_id: string;
  current_balance: number;
  total_received: number;
  total_spent: number;
  last_activity: string;
  profile?: Profile;
}

export interface Budget {
  budget_id: string;
  project_id: string;
  phase_id: string;
  category_id: string;
  planned_amount: number;
  actual_amount: number;
  variance: number;
}

export interface FinancialEvent {
  event_id: string;
  project_id: string;
  phase_id: string;
  category_id: string;
  supplier_id?: string;
  wallet_id?: string;
  user_id: string;
  event_type: EventType;
  amount: number;
  payment_method: PaymentMethod;
  description?: string;
  attachment_url?: string;
  status: EventStatus;
  created_at: string;
  phase?: Phase;
  category?: Category;
  supplier?: Supplier;
  profile?: Profile;
  wallet?: Wallet;
}

export interface TransactionMeta {
  meta_id: string;
  event_id: string;
  meta_key: string;
  meta_value: string;
}

export interface DocumentItem {
  document_id: string;
  project_id: string;
  document_type: string;
  document_name: string;
  expiry_date?: string;
  attachment_url: string;
  created_at: string;
}

export interface ProjectTemplate {
  template_id: string;
  project_type: ProjectType;
  default_phases: { name: string; order: number }[];
}
