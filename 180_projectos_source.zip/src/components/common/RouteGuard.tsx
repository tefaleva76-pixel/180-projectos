import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const RouteGuard: React.FC<{ children: React.ReactNode; public?: boolean }> = ({ children, public: isPublic }) => {
  const { isAuthenticated, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-[#3ECFCF] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated && !isPublic) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (isAuthenticated && isPublic) {
    return <Navigate to="/portfolio" replace />;
  }

  return <>{children}</>;
};

export default RouteGuard;
