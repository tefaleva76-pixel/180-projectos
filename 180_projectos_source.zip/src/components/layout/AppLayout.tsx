import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth, useRole } from '@/contexts/AuthContext';
import {
  LayoutDashboard,
  FolderKanban,
  Wallet,
  Settings,
  FileText,
  Search,
  BarChart3,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Landmark,
} from 'lucide-react';

interface NavItem {
  label: string;
  path: string;
  icon: React.ReactNode;
  roles: string[];
}

const navItems: NavItem[] = [
  { label: 'محفظة المشاريع', path: '/portfolio', icon: <FolderKanban size={20} />, roles: ['Owner', 'Accountant', 'Site_Engineer'] },
  { label: 'لوحة التحكم المالي', path: '/dashboard', icon: <LayoutDashboard size={20} />, roles: ['Owner', 'Accountant', 'Site_Engineer'] },
  { label: 'العهد النقدية', path: '/wallets', icon: <Wallet size={20} />, roles: ['Owner', 'Accountant'] },
  { label: 'إدارة المشروع', path: '/management', icon: <Settings size={20} />, roles: ['Owner'] },
  { label: 'التقارير', path: '/reports', icon: <BarChart3 size={20} />, roles: ['Owner', 'Accountant'] },
  { label: 'البحث العام', path: '/search', icon: <Search size={20} />, roles: ['Owner', 'Accountant', 'Site_Engineer'] },
  { label: 'مركز المستندات', path: '/documents', icon: <FileText size={20} />, roles: ['Owner', 'Accountant', 'Site_Engineer'] },
];

const AppLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { logout, profile } = useAuth();
  const role = useRole();
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const filteredNav = navItems.filter(item => role && item.roles.includes(role));

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const MobileBottomNav = () => (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-border shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] pb-safe">
      <div className="flex items-center justify-around px-2 py-2">
        <button onClick={() => navigate('/portfolio')} className={`flex flex-col items-center gap-1 p-2 min-w-[64px] ${location.pathname.startsWith('/portfolio') || location.pathname.startsWith('/dashboard') ? 'text-[#3ECFCF]' : 'text-muted-foreground'}`}>
          <BarChart3 size={20} />
          <span className="text-[10px] font-medium">الرئيسية</span>
        </button>
        <button onClick={() => navigate('/search')} className={`flex flex-col items-center gap-1 p-2 min-w-[64px] ${location.pathname.startsWith('/search') ? 'text-[#3ECFCF]' : 'text-muted-foreground'}`}>
          <Search size={20} />
          <span className="text-[10px] font-medium">بحث</span>
        </button>
        <button onClick={() => navigate('/wallets')} className={`flex flex-col items-center gap-1 p-2 min-w-[64px] ${location.pathname.startsWith('/wallets') ? 'text-[#3ECFCF]' : 'text-muted-foreground'}`}>
          <Wallet size={20} />
          <span className="text-[10px] font-medium">العهد</span>
        </button>
        <button onClick={() => navigate('/documents')} className={`flex flex-col items-center gap-1 p-2 min-w-[64px] ${location.pathname.startsWith('/documents') ? 'text-[#3ECFCF]' : 'text-muted-foreground'}`}>
          <FileText size={20} />
          <span className="text-[10px] font-medium">المستندات</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen w-full bg-background pb-16 md:pb-0" dir="rtl">
      {/* Mobile Burger Overlay */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-[60] bg-black/50" onClick={() => setMobileMenuOpen(false)} />
      )}

      {/* Sidebar */}
      <aside
        className={`print:hidden fixed md:sticky top-0 right-0 z-[70] bg-white border-l border-border shadow-sm transition-all duration-300 flex flex-col h-[100dvh] shrink-0 ${
          collapsed ? 'w-20' : 'w-[280px]'
        } ${mobileMenuOpen ? 'translate-x-0' : 'translate-x-full md:translate-x-0'}`}
      >
        {/* Logo */}
        <div className="flex items-center justify-between border-b border-border py-4 px-4 h-24 shrink-0">
          <div className="flex-1 flex justify-center h-full">
            <img 
              src="/ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico" 
              alt="180° ProjectOS Logo" 
              className={`object-contain transition-all ${collapsed ? 'h-10' : 'h-16 max-h-full'}`} 
            />
          </div>
          {mobileMenuOpen && (
            <button onClick={() => setMobileMenuOpen(false)} className="md:hidden text-muted-foreground p-1 shrink-0">
              <ChevronRight size={24} />
            </button>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-1">
          {filteredNav.map(item => {
            const isActive = location.pathname === item.path || location.pathname.startsWith(item.path + '/');
            return (
              <button
                key={item.path}
                onClick={() => { navigate(item.path); setMobileMenuOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-[#3ECFCF]/10 text-[#1A1A1A]'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
                title={collapsed ? item.label : undefined}
              >
                <span className={isActive ? 'text-[#3ECFCF]' : ''}>{item.icon}</span>
                {!collapsed && <span>{item.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* Bottom */}
        <div className="border-t border-border p-3 space-y-2 shrink-0">
          {!collapsed && profile && (
            <div className="px-3 py-2">
              <div className="text-sm font-semibold text-foreground">{profile.name}</div>
              <div className="text-xs text-muted-foreground">
                {profile.role === 'Owner' ? 'المالك' : profile.role === 'Accountant' ? 'المحاسب' : 'مهندس الموقع'}
              </div>
            </div>
          )}
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"
            title={collapsed ? 'تسجيل الخروج' : undefined}
          >
            <LogOut size={20} />
            {!collapsed && <span>تسجيل الخروج</span>}
          </button>
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="hidden md:flex w-full items-center justify-center py-1 text-muted-foreground hover:text-foreground"
          >
            {collapsed ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 transition-all duration-300 print:m-0">
        {/* Global Search Header */}
        <div className="print:hidden sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border px-4 md:px-6 py-3 flex items-center gap-4">
          <button onClick={() => setMobileMenuOpen(true)} className="md:hidden shrink-0 text-foreground p-2 -mr-2">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
          </button>
          
          <div className="md:hidden flex-shrink-0 ml-2 h-8">
            <img src="/ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico" alt="180° ProjectOS Logo" className="h-full w-auto object-contain" />
          </div>

          <form 
            className="flex-1 max-w-md relative"
            onSubmit={(e) => {
              e.preventDefault();
              const q = (e.currentTarget.elements.namedItem('searchQuery') as HTMLInputElement).value;
              if (q.trim()) navigate(`/search?q=${encodeURIComponent(q.trim())}`);
            }}
          >
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <input 
              name="searchQuery"
              type="text" 
              placeholder="بحث..." 
              className="w-full pl-4 pr-10 py-2 rounded-xl border border-border bg-white text-sm focus:outline-none focus:ring-2 focus:ring-[#3ECFCF]/50 transition-all"
            />
          </form>
        </div>

        <div className="flex-1 overflow-x-hidden min-w-0">
          {children}
        </div>
      </main>
      
      <MobileBottomNav />
    </div>
  );
};

export default AppLayout;
