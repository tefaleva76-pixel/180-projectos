# Requirements Document

## 1. Application Overview

**Application Name:** 180° ProjectOS

**Description:** A multi-tenant construction project financial management platform designed for Arabic-speaking markets. The system enables construction companies to manage projects, track finances, control petty cash, manage documents, and generate reports with role-based access control.

## 2. Users and Usage Scenarios

### 2.1 Target Users

- **Owner:** Company owner with full system access
- **Accountant:** Financial staff responsible for reviewing and approving transactions
- **Site Engineer:** Field personnel who submit expenses and manage petty cash

### 2.2 Core Usage Scenarios

- Track construction project expenses across multiple phases and categories
- Manage petty cash wallets for site engineers
- Submit and approve financial events with supporting documentation
- Monitor budget consumption and generate financial reports
- Store and track project documents with expiry alerts

## 3. Page Structure and Functionality

### Page Hierarchy

```
180° ProjectOS
├── 1. Login (تسجيل الدخول)
├── 2. Project Portfolio (محفظة المشاريع)
│   └── 3. New Project (إنشاء مشروع جديد)
├── 4. Financial Command Center (لوحة التحكم المالي)
│   └── 5. Add Financial Event (إضافة حدث مالي)
├── 6. Petty Cash Management (إدارة العهد النقدية)
├── 7. RBAC (نظام الصلاحيات)
├── 8. Project Management CRUD (إدارة المشروع)
├── 9. Reports & PDF Export (التقارير)
├── 10. Global Search (البحث العام)
└── 11. Document Center (مركز المستندات)
```

### 3.1 Login Screen (تسجيل الدخول)

**Purpose:** User authentication and system entry

**Elements:**
- Vertical 180° logo (ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico) displayed centered and large
- Tagline: \"إدارة كل مشروع. تتبع كل جنيه.\"
- Email input field (Arabic label)
- Password input field (Arabic label)
- Black login button with Arabic text
- Footer text: \"مدعوم من 180°\"

**Functionality:**
- User enters email and password
- System authenticates via Supabase Auth
- On successful login, fetch user profile including role and company_id
- Store role and company_id in session
- Redirect to Project Portfolio screen
- Display Arabic error message if authentication fails
- Render uploaded vertical logo file (ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico) exactly as provided without modification

### 3.2 Project Portfolio (محفظة المشاريع)

**Purpose:** Display all company projects with key metrics

**Elements:**
- Project cards showing: project name, project type icon, total spend amount, budget progress bar
- Filter tabs: الكل (All) / قيد التنفيذ (In Progress) / مكتمل (Completed)
- Floating + مشروع جديد button

**Functionality:**
- Display all projects belonging to user's company (filtered by company_id)
- Show project type icon based on project type
- Calculate and display total spend per project
- Show budget consumption progress bar
- Filter projects by status when user clicks filter tabs
- Click project card to navigate to Financial Command Center for that project
- Click + مشروع جديد button to navigate to New Project screen

### 3.3 New Project (إنشاء مشروع جديد)

**Purpose:** Create new construction project with phases

**Elements:**
- 3-step form wizard
  - Step 1: Project name, location, total budget (Arabic input fields)
  - Step 2: Project type selection (6 Arabic buttons: Residential / Industrial / Farm / Hotel / Mall / Custom)
  - Step 3: Auto-generated phases list (editable) based on selected project type template

**Functionality:**
- User completes Step 1 with basic project information
- User selects project type in Step 2
- System retrieves corresponding template from project_templates table
- System displays auto-generated phases in Step 3 (user can edit phase names, add or remove phases)
- On save:
  - Insert project record to projects table with company_id from session
  - Insert all phases to phases table linked to new project
  - Display success toast in Arabic
  - Navigate back to Project Portfolio
- Display Arabic validation errors if required fields are empty
- All frontend input fields linked to Supabase database tables

### 3.4 Financial Command Center (لوحة التحكم المالي)

**Purpose:** Main dashboard for financial overview and activity monitoring

**Elements:**
- 4 KPI cards: Total Expenses, Budget Consumption %, Pending Events Count, Total Invoices Count
- Pie chart: Expenses by category
- Bar chart: Planned vs Actual budget comparison
- Live Activity Feed showing recent financial events
- Floating + إضافة حدث مالي button
- Premium Arabic RTL UI components for Dashboard layout
- Premium Arabic RTL UI components for Live Activity Feed

**Functionality:**
- Calculate and display total expenses for selected project
- Calculate budget consumption percentage (actual/planned × 100)
- Count pending financial events awaiting approval
- Count total invoices attached to financial events
- Display pie chart with expense breakdown by category
- Display bar chart comparing planned budget vs actual spend per phase
- Show real-time activity feed via Supabase Realtime subscription
- Click + إضافة حدث مالي to navigate to Add Financial Event screen
- Auto-refresh KPI cards when financial events are added or approved
- All frontend input fields linked to Supabase database tables
- Dashboard and Live Activity Feed use premium Arabic RTL UI components

### 3.5 Add Financial Event (إضافة حدث مالي)

**Purpose:** Record financial transactions with type-specific details

**Elements:**
- Grid of 8 event type buttons (Arabic labels)
- Dynamic form fields based on selected event type
- Save button with loading spinner
- Arabic validation error messages

**Event Types and Fields:**

1. **مصروف (Expense):** Amount, Category (chips), Phase, Payment Method, Description, Invoice Photo Upload
2. **شراء أصل (Asset Purchase):** Machine Name, Manufacturer, Serial Number, Value, Warranty Period, Shipping Cost, Customs Cost, Installation Cost
3. **شحن عهدة (Wallet Top-up):** Select Engineer, Amount, Notes
4. **صرف من العهدة (Wallet Withdrawal):** Display Current Wallet Balance, Amount (auto-deduct from balance), Description
5. **دفعة مورد (Supplier Payment):** Supplier Name, Invoice Number, Amount, Payment Type (Partial/Full)
6. **راتب (Salary/Wage):** Employee Name, Daily Rate, Number of Days, Amount Paid, Remaining Amount
7. **إيراد (Revenue):** Source, Amount, Description
8. **Other types:** Rent, Maintenance, Return, Advance, Provision (with relevant fields)

**Functionality:**
- User selects event type
- System displays relevant form fields for selected type
- User fills in required fields
- For invoice photo: upload to Supabase Storage and save URL
- Extra fields beyond core schema saved to transaction_meta table as key-value pairs
- Auto-set status based on user role:
  - Site_Engineer: status = Pending
  - Owner/Accountant: status = Approved
- Validate all required fields before save
- Display Arabic error messages under invalid fields
- Show loading spinner in save button during submission
- On successful save:
  - Insert record to financial_events table with company_id and user_id from session
  - If status = Approved, trigger database update for budgets and wallets
  - Display green success toast in Arabic
  - Navigate back to Financial Command Center
- Block save if wallet balance insufficient for صرف من العهدة with Arabic error message
- Warn user if expense exceeds remaining budget before saving
- All frontend input fields linked to Supabase database tables
- Full CRUD flexibility: User can edit or delete any financial event (subject to role permissions)

### 3.6 Petty Cash Management (إدارة العهد النقدية)

**Purpose:** Track and manage engineer petty cash wallets

**Elements:**
- List of all engineer wallets showing: Engineer Name, Current Balance, Total Received, Total Spent, Last Activity Date
- Progress bar per wallet (orange warning if balance < 10% of total received)
- \"شحن عهدة\" button per wallet (Owner only)
- Transaction history per wallet

**Functionality:**
- Display all wallets for company (filtered by company_id)
- Calculate current balance, total received, total spent per wallet
- Show orange progress bar if current balance < 10% of total received
- Owner clicks \"شحن عهدة\" to top up wallet (opens Add Financial Event with type pre-selected)
- Click wallet to view transaction history
- For Site_Engineer role: Display persistent wallet balance banner on all screens showing their own wallet only
- For Site_Engineer role: Hide other engineers' wallet data
- Real-time Petty Cash Trigger logic: When financial event status changes to Approved and event type is شحن عهدة or صرف من العهدة, automatically update wallet balance in real-time
- All frontend input fields linked to Supabase database tables

### 3.7 RBAC (نظام الصلاحيات)

**Purpose:** Role-based access control and permission management

**Role Permissions:**

**Owner:**
- Full system access
- Manage users, categories, phases, suppliers
- Approve/reject financial events
- Export PDF reports
- Top up engineer wallets
- View all financial data and totals
- Edit and delete any financial event

**Accountant:**
- View all financial events
- Search and filter transactions
- Approve/reject pending events
- Download reports
- View all financial data and totals
- Cannot manage users or project structure
- Edit and delete financial events (limited to own submissions or pending events)

**Site_Engineer:**
- Add financial events only (status auto-set to Pending)
- Upload invoice photos
- View own wallet balance and transaction history
- View own submitted events only
- Cannot view financial totals
- Cannot view other engineers' data
- Cannot approve/reject events
- Edit and delete own financial events only (before approval)

**Functionality:**
- System checks user role from session on every screen load
- Display different navigation menu items based on role
- Hide/show UI elements based on role permissions
- Block unauthorized actions at both UI and data layer
- Filter data queries by role (e.g., Site_Engineer sees only own submissions)

### 3.8 Project Management CRUD (إدارة المشروع)

**Purpose:** Manage project structure components (Owner only)

**Elements:**
- Tabs for: Phases, Categories, Suppliers, Budget Assignments
- List view with تعديل and حذف buttons per row
- Add new button per tab
- Arabic confirmation dialog for delete actions
- Sidebar displaying vertical 180° logo (ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico)

**Functionality:**

**Phases Management:**
- Display all phases for selected project
- Add new phase: name, status, start date, end date
- Edit phase: update any field
- Delete phase: show confirmation \"هل أنت متأكد من الحذف؟ لا يمكن التراجع.\" → cascade delete related budgets and financial events → recalculate project totals

**Categories Management:**
- Display all categories for selected project
- Add new category: name, icon, color
- Edit category: update any field
- Delete category: show confirmation → cascade update related financial events → recalculate budgets

**Suppliers Management:**
- Display all suppliers for company
- Add new supplier: name, contact info, address
- Edit supplier: update any field
- Delete supplier: show confirmation → update related financial events to remove supplier reference

**Budget Assignments:**
- Display budget table: rows = phases, columns = categories, cells = planned amount
- Edit cell to update planned budget
- System auto-calculates actual spend from financial events
- Display variance (actual - planned) per cell
- Highlight cells in red if actual > planned

**General Rules:**
- All CRUD operations restricted to Owner role only
- After any delete operation, system recalculates all dependent budgets and wallet balances
- Display success/error toast in Arabic after each operation
- Instant UI update after changes
- Render uploaded vertical logo file (ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico) in Sidebar exactly as provided without modification

### 3.9 Reports & PDF Export (التقارير)

**Purpose:** Generate financial reports and export to PDF

**Elements:**
- Tab 1: Live Charts (bar chart by phase, pie chart by category, monthly trend line chart)
- Tab 2: Detailed Report (filters + table view)
- Tab 3: PDF Export (formatted report with logo)

**Functionality:**

**Tab 1 - Live Charts:**
- Bar chart: Total spend per phase
- Pie chart: Total spend per category
- Line chart: Monthly spending trend
- Charts auto-update when financial data changes

**Tab 2 - Detailed Report:**
- Filters: Date Range, Phase, Category, Event Type, User, Status
- Apply filters to display matching financial events in table
- Table columns: Date, Event Type, Amount, Category, Phase, User, Status, Actions
- Click row to view full transaction details

**Tab 3 - PDF Export:**
- Header: Vertical 180° logo (ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico rendered exactly as provided) + Project Name + Report Date
- Summary section: Total Expenses, Budget Consumption %, Expense by Category table
- Transactions section: Full table of all financial events with filters applied
- Footer: Black background with gold text \"Generated via 180° ProjectOS | Powered by 180°\"
- Click export button to generate and download PDF

### 3.10 Global Search (البحث العام)

**Purpose:** Search financial events across entire system

**Elements:**
- Search bar (visible on every screen)
- Filter buttons: الكل / معلق / معتمد / هذا الشهر / حسب الفئة
- Search results list

**Functionality:**
- User types in search bar
- System performs real-time search in financial_events table (filtered by company_id)
- Search fields: description, supplier name, employee name, invoice number
- Display results as user types
- Each result shows: Amount, Category, Phase, User, Date, Status Badge
- Apply filter buttons to narrow results
- Click result to view full transaction detail with edit/delete options (if user has permission)

### 3.11 Document Center (مركز المستندات)

**Purpose:** Store and manage project documents with expiry tracking

**Elements:**
- Document list showing: Document Name, Type, Upload Date, Expiry Date, Status Badge
- Filter dropdown by document type
- Upload button
- تعديل and حذف buttons per document

**Document Types:**
- فاتورة (Invoice)
- عقد (Contract)
- ترخيص رسمي (Official License)
- دراسة بيئية (Environmental Study)
- إيصال (Receipt)
- سجل ضريبي (Tax Record)

**Functionality:**
- Display all documents for selected project
- Show expiry alert badge (red) if expiry date < 30 days from current date (2026-06-24)
- Filter documents by type using dropdown
- Upload document:
  - User selects file and fills in: Document Name, Type, Expiry Date (optional)
  - System uploads file to Supabase Storage bucket
  - System saves document record to documents table with file URL
  - Display success toast in Arabic
- Edit document: Update name, type, or expiry date
- Delete document:
  - Show Arabic confirmation dialog
  - Delete file from Supabase Storage
  - Delete record from documents table
  - Display success toast in Arabic

## 4. Business Rules and Logic

### 4.1 Multi-Tenant Isolation
- Every database table includes company_id column
- All INSERT operations must inject company_id from user session
- All SELECT queries must filter by company_id from user session
- Users can only access data belonging to their company

### 4.2 Financial Event Status Workflow
- Site_Engineer creates event → status = Pending
- Owner or Accountant creates event → status = Approved
- Owner or Accountant can approve Pending event → status changes to Approved → triggers database update
- Owner or Accountant can reject Pending event → status changes to Rejected → no financial impact
- Only Approved events affect budgets and wallet balances

### 4.3 Budget Calculation and Alerts
- Planned budget set per (project, phase, category) combination
- Actual spend calculated by summing all Approved financial events for same (project, phase, category)
- Variance = Actual - Planned
- If Actual > Planned: Display تجاوز الميزانية in red
- If 90% ≤ (Actual/Planned) < 100%: Display orange progress bar
- Before saving new expense event: Check if it will exceed budget → warn user with Arabic message

### 4.4 Petty Cash Wallet Rules
- Each Site_Engineer has one wallet per company
- Wallet fields: current_balance, total_received, total_spent
- Only Owner can perform \"شحن عهدة\" (top up wallet)
- When Owner tops up wallet:
  - Create financial event with type = شحن عهدة, status = Approved
  - Increase wallet.current_balance and wallet.total_received
- When Site_Engineer performs \"صرف من العهدة\" (withdraw from wallet):
  - Check if wallet.current_balance ≥ requested amount
  - If insufficient: Block save with Arabic error message
  - If sufficient: Create financial event with type = صرف من العهدة, payment_method = من العهدة النقدية
  - Decrease wallet.current_balance and increase wallet.total_spent
- Display persistent wallet balance banner for Site_Engineer on all screens
- Real-time Petty Cash Trigger: Automatically update wallet balance when financial event status changes to Approved for شحن عهدة or صرف من العهدة event types

### 4.5 Database Triggers
- **handle_new_user trigger:** When new user signs up via Supabase Auth, auto-create profile record in profiles table
- **process_wallet_update trigger:** When financial_event status changes to Approved:
  - If event type = شحن عهدة: Update wallet balance (increase)
  - If event type = صرف من العهدة: Update wallet balance (decrease)
  - Update budgets table: Recalculate actual spend for affected (project, phase, category)
- Real-time Petty Cash Trigger logic fully implemented for automatic wallet balance updates

### 4.6 Real-Time Updates
- Activity feed on Financial Command Center subscribes to financial_events table via Supabase Realtime
- When new event inserted or status updated: Activity feed auto-refreshes
- KPI cards auto-refresh after financial event changes

### 4.7 Offline Mode
- When user loses internet connection: Cache pending transactions in browser localStorage
- Display sync status indicator:
  - \"متزامن\" when online and synced
  - \"في انتظار المزامنة (X حركات معلقة)\" when offline with pending transactions
- When connection restored: Auto-sync cached transactions to Supabase
- Display success toast in Arabic after sync completes

### 4.8 Form Validation
- All required fields must be filled before form submission
- Display Arabic error message under each invalid field
- Disable submit button while form is submitting
- Show loading spinner in submit button during submission
- Display green toast on successful save
- Display red toast on error with Arabic error message

### 4.9 CRUD Operations
- Every list item (phase, category, supplier, document, financial event) has تعديل and حذف buttons
- Edit: Open form with pre-filled data → user modifies → save → instant UI update
- Delete: Show Arabic confirmation dialog \"هل أنت متأكد من الحذف؟ لا يمكن التراجع.\" → user confirms → delete record → cascade delete related records → recalculate budgets and wallets → instant UI update
- Full CRUD flexibility for financial events: Users can edit and delete events based on role permissions

### 4.10 Project Templates
- System includes 6 pre-defined project templates: Residential, Industrial, Farm, Hotel, Mall, Custom
- Each template stored in project_templates table with default phases (JSON format)
- When user creates new project and selects type: System retrieves template and auto-generates phases
- User can edit, add, or remove phases before saving project

### 4.11 Frontend-Database Integration
- All verified frontend input fields linked to Supabase database tables
- Data flow: User input → form validation → Supabase insert/update/delete → real-time UI update
- Applies to all screens: Login, Portfolio, New Project, Dashboard, AddEvent, Wallets, Project Management CRUD, Reports, Global Search, Document Center

### 4.12 UI Component Standards
- Premium Arabic RTL UI components used for Dashboard layout
- Premium Arabic RTL UI components used for Live Activity Feed
- Vertical 180° logo (ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico) rendered exactly as provided in Sidebar and Login layouts without modification

## 5. Exceptions and Edge Cases

| Scenario | Handling |
|----------|----------|
| User tries to delete phase with existing financial events | Show Arabic error: \"لا يمكن حذف المرحلة. يوجد حركات مالية مرتبطة بها.\" Block deletion |
| Site_Engineer tries to withdraw more than wallet balance | Show Arabic error under amount field: \"الرصيد غير كافٍ. الرصيد الحالي: X جنيه\" Block save |
| User uploads file larger than 10MB | Show Arabic error: \"حجم الملف كبير جداً. الحد الأقصى 10 ميجابايت\" Block upload |
| User tries to approve already approved event | Show Arabic error: \"هذا الحدث معتمد بالفعل\" Block action |
| User loses connection while submitting form | Cache form data in localStorage, show offline indicator, auto-submit when connection restored |
| Document expiry date is past | Display red badge \"منتهي الصلاحية\" on document card |
| Budget actual exceeds planned by >20% | Display red alert banner on Financial Command Center: \"تحذير: تجاوز الميزانية بنسبة X%\" |
| User tries to access screen without permission | Redirect to Project Portfolio with Arabic error toast: \"ليس لديك صلاحية للوصول إلى هذه الصفحة\" |
| Multiple users edit same record simultaneously | Last save wins, show warning toast: \"تم تحديث هذا السجل من قبل مستخدم آخر\" |
| User searches with no results | Display Arabic message: \"لا توجد نتائج\" |
| User tries to edit or delete financial event without permission | Show Arabic error: \"ليس لديك صلاحية لتعديل أو حذف هذا الحدث\" Block action |
| Real-time Petty Cash Trigger fails to execute | Log error, display Arabic error toast: \"فشل تحديث رصيد العهدة. يرجى المحاولة مرة أخرى\" |
| Vertical logo file (ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico) fails to load | Display fallback text \"180°\" in same position |

## 6. Acceptance Criteria

1. Owner logs in with email and password → sees Project Portfolio with all company projects → vertical logo (ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico) displayed exactly as provided in Login screen
2. Owner creates new Residential project with name \"Villa Construction\" and budget 500,000 → system auto-generates 5 phases from template → Owner saves project → project appears in Portfolio → all input fields successfully linked to Supabase projects and phases tables
3. Owner navigates to Financial Command Center for \"Villa Construction\" → sees 4 KPI cards showing 0 expenses → Dashboard uses premium Arabic RTL UI components → clicks + إضافة حدث مالي → selects مصروف → fills amount 5,000, category \"مواد بناء\", phase \"الأساسات\", payment method \"كاش\" → uploads invoice photo → saves → event status = Approved → KPI cards update to show 5,000 total expenses → all input fields successfully linked to Supabase financial_events table
4. Owner navigates to Petty Cash Management → clicks \"شحن عهدة\" for Site_Engineer \"أحمد\" → enters amount 10,000 → saves → Ahmed's wallet balance increases to 10,000 → real-time Petty Cash Trigger executes successfully → wallet balance updated in Supabase wallets table
5. Site_Engineer \"أحمد\" logs in → sees persistent wallet banner showing balance 10,000 → navigates to Financial Command Center → Live Activity Feed uses premium Arabic RTL UI components → clicks + إضافة حدث مالي → selects صرف من العهدة → enters amount 2,000 → saves → event status = Pending → wallet balance decreases to 8,000 → real-time Petty Cash Trigger executes successfully
6. Accountant logs in → navigates to Financial Command Center → sees 1 pending event from \"أحمد\" → clicks approve → event status changes to Approved → budgets update → Ahmed can edit or delete this event before approval
7. Owner navigates to Reports → Tab 3 PDF Export → clicks export → PDF downloads with vertical 180° logo (ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico) rendered exactly as provided in header, project name, summary totals, full transactions table, and footer \"Generated via 180° ProjectOS | Powered by 180°\"
8. Owner navigates to Document Center → uploads contract file with expiry date 2026-07-15 → document appears in list with no alert badge (expiry > 30 days away) → Owner edits document name → Owner deletes document → full CRUD flexibility confirmed
9. Owner navigates to Project Management CRUD → Sidebar displays vertical logo (ChatGPT-Image-Jan-27_-2026_-10_37_09-AM.ico) exactly as provided → Owner adds new phase → edits phase name → deletes phase → all CRUD operations successfully linked to Supabase phases table
10. Site_Engineer \"أحمد\" navigates to Financial Command Center → clicks on own submitted event → clicks تعديل → modifies description → saves → event updated successfully → clicks حذف → confirms deletion → event deleted successfully → full CRUD flexibility for own events confirmed

## 7. Out of Scope for This Release

- Mobile native apps (iOS/Android)
- Multi-language support (only Arabic in this release)
- Integration with external accounting software
- Automated bank statement import
- Email/SMS notifications for approvals or alerts
- Advanced analytics and forecasting
- Gantt chart or timeline view for project scheduling
- Inventory management for construction materials
- Equipment rental tracking
- Subcontractor management module
- Time tracking for labor hours
- Photo gallery for project progress documentation
- Client portal for external stakeholders
- Custom report builder with drag-and-drop
- Data export to Excel/CSV (only PDF export included)
- Audit log viewer UI (audit_logs table exists but no UI)
- Two-factor authentication
- Password reset via email
- User profile customization (avatar, preferences)
- Dark mode theme
- Keyboard shortcuts
- Bulk operations (bulk approve, bulk delete)
- Advanced search with boolean operators
- Document version control
- Document e-signature integration
- Automated document expiry email reminders
- Budget templates library
- Project cloning/duplication
- Archived projects view
- Deleted items recovery (recycle bin)
- Activity log filtering and export
- Custom fields for financial events beyond transaction_meta
- Recurring expenses automation
- Multi-currency support
- Tax calculation and reporting
- Profit margin analysis
- Cash flow forecasting
- Supplier performance ratings
- Purchase order management
- Invoice approval workflow (multi-level)
- Payment scheduling and reminders
- Bank reconciliation
- Petty cash reconciliation reports
- Expense reimbursement workflow